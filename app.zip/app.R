options(shiny.maxRequestSize = 300 * 1024^2)

if (!exists("load_or_install", mode = "function")) {
  load_or_install <- function(pkgs) {
    for (p in pkgs) if (!requireNamespace(p, quietly = TRUE)) install.packages(p, repos = "https://cloud.r-project.org")
  }
}
if (!exists("%||%", mode = "function")) {
  `%||%` <- function(x, y) if (is.null(x) || length(x) == 0 || all(is.na(x))) y else x
}

APP_DIR <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
app_path <- function(...) file.path(APP_DIR, ...)
message(sprintf("[app] APP_DIR = %s", APP_DIR))

required_pkgs <- c(
  "shiny", "pdftools", "readr", "dplyr", "stringr", "tibble",
  "udpipe", "stopwords", "igraph", "visNetwork", "DT", "scales",
  "ggplot2", "htmltools", "ggrepel", "networkD3", "plotly", "xml2", "httr", "stringi",
  "reticulate"
)
load_or_install(required_pkgs)
invisible(lapply(required_pkgs, library, character.only = TRUE))

r_files <- list.files(app_path("R"), pattern = "\\.[Rr]$", full.names = TRUE)
for (f in sort(r_files)) source(f, local = TRUE, encoding = "UTF-8")

if (file.exists(app_path("mesh_keyword_validation.R"))) source(app_path("mesh_keyword_validation.R"), local = TRUE, encoding = "UTF-8")

# restore original SSplot support when bundled files are present
if (file.exists(app_path("renderSSplot.R"))) {
  try(source(app_path("renderSSplot.R"), local = TRUE, encoding = "UTF-8"), silent = TRUE)
}
if (file.exists(app_path("appAAC.R"))) {
  try(source(app_path("appAAC.R"), local = TRUE, encoding = "UTF-8"), silent = TRUE)
}

mesh_empty_result <- function(msg = "MeSH keyword validation not run.") {
  list(
    summary = tibble::tibble(check = "MeSH validation", status = "Info", details = msg),
    candidates = tibble::tibble(term = character(0), source = character(0), tier = character(0), pubmed_hit_count = integer(0), mesh_exact = logical(0), mesh_partial = logical(0), reference_mesh_support = logical(0), mesh_terms_found = character(0), pmid_examples = character(0), mesh_supported = logical(0), confidence = character(0)),
    reference_mesh = tibble::tibble(ref_no = integer(0), pmid = character(0), mesh_term = character(0), mesh_major = character(0), matched_by = character(0)),
    priority = list(essential_terms = character(0), basic_terms = character(0), additional_terms = character(0), title_text = "", abstract_text = "")
  )
}

# =========================================================
# Python reference extraction bridge
# =========================================================
reference_py_loaded <- FALSE
reference_py_path <- NULL

local({
  py_candidates <- c(
    app_path("reference_extraction.py"),
    app_path("python", "reference_extraction.py"),
    "reference_extraction.py",
    file.path("python", "reference_extraction.py")
  )

  py_candidates <- unique(normalizePath(py_candidates, winslash = "/", mustWork = FALSE))
  py_exists <- py_candidates[file.exists(py_candidates)]

  py_bin <- Sys.getenv("RETICULATE_PYTHON", unset = "")
  if (!nzchar(py_bin) || !file.exists(py_bin)) {
    py_bin <- Sys.which("python")
    if (!nzchar(py_bin)) py_bin <- Sys.which("python3")
  }
  if (!nzchar(py_bin) || !file.exists(py_bin)) py_bin <- ""

  if (length(py_exists) > 0 && nzchar(py_bin)) {
    reference_py_path <<- py_exists[1]

    tryCatch({
      try(reticulate::use_python(py_bin, required = FALSE), silent = TRUE)
      reticulate::source_python(reference_py_path)
      reference_py_loaded <<- TRUE
      message(sprintf("[OK] Loaded Python reference module: %s", reference_py_path))
    }, error = function(e) {
      reference_py_loaded <<- FALSE
      warning(sprintf("Failed to load reference_extraction.py: %s", e$message))
    })
  } else if (length(py_exists) > 0) {
    reference_py_loaded <<- FALSE
    warning("Python not found in PATH. Skipping reference_extraction.py and using R fallback.")
  } else {
    warning("reference_extraction.py not found. Expected at app root or ./python/")
  }
})

py_reference_available <- function() {
  isTRUE(reference_py_loaded) &&
    exists("extract_reference_section", mode = "function") &&
    exists("extract_reference_coword_rows", mode = "function")
}

py_extract_reference_section_safe <- function(full_text) {
  if (!py_reference_available()) {
    return(list(
      found = FALSE,
      start_index = NULL,
      reference_text = "",
      references = list(),
      count = 0L,
      error = "Python reference_extraction.py not loaded"
    ))
  }

  full_text <- as.character(full_text %||% "")

  tryCatch({
    res <- extract_reference_section(full_text)

    list(
      found = isTRUE(res$found),
      start_index = res$start_index %||% NULL,
      reference_text = as.character(res$reference_text %||% ""),
      references = as.character(unlist(res$references %||% list())),
      count = as.integer(res$count %||% 0L),
      error = NULL
    )
  }, error = function(e) {
    list(
      found = FALSE,
      start_index = NULL,
      reference_text = "",
      references = list(),
      count = 0L,
      error = as.character(e$message)
    )
  })
}

py_extract_reference_coword_rows_safe <- function(full_text) {
  if (!py_reference_available()) {
    return(tibble::tibble(
      ref_no = character(0),
      reference_raw = character(0),
      reference_clean = character(0)
    ))
  }

  full_text <- as.character(full_text %||% "")

  tryCatch({
    rows <- extract_reference_coword_rows(full_text)

    if (is.null(rows) || length(rows) == 0) {
      return(tibble::tibble(
        ref_no = character(0),
        reference_raw = character(0),
        reference_clean = character(0)
      ))
    }

    if (is.data.frame(rows)) {
      out <- tibble::as_tibble(rows)
    } else {
      out <- tibble::as_tibble(do.call(rbind, lapply(rows, function(x) {
        data.frame(
          ref_no = as.character(x$ref_no %||% ""),
          reference_raw = as.character(x$reference_raw %||% ""),
          reference_clean = as.character(x$reference_clean %||% ""),
          stringsAsFactors = FALSE
        )
      })))
    }

    need_cols <- c("ref_no", "reference_raw", "reference_clean")
    for (nm in setdiff(need_cols, names(out))) out[[nm]] <- ""
    out[, need_cols, drop = FALSE]
  }, error = function(e) {
    warning(sprintf("py_extract_reference_coword_rows_safe failed: %s", e$message))
    tibble::tibble(
      ref_no = character(0),
      reference_raw = character(0),
      reference_clean = character(0)
    )
  })

}
normalize_reference_text_r <- function(text) {
  text <- paste(as.character(text %||% ""), collapse = "\n")
  text <- gsub("\r\n?", "\n", text)
  text <- gsub("\u00a0", " ", text, fixed = TRUE)
  text <- gsub("[\u2013\u2014\u2212]", "-", text, perl = TRUE)
  text <- gsub("(?<=\\w)-\\n(?=\\w)", "", text, perl = TRUE)
  text <- gsub("[ \t]+", " ", text, perl = TRUE)
  text <- gsub("\n{3,}", "\n\n", text, perl = TRUE)
  trimws(text)
}

strip_reference_noise_line_r <- function(line) {
  s <- trimws(as.character(line %||% ""))
  if (!nzchar(s)) return("")
  if (grepl("^[0-9]+$", s)) return("")
  s <- sub("^[0-9]+[[:space:]]+(?=[0-9]+[.])", "", s, perl = TRUE)
  s
}

extract_reference_section_r <- function(full_text) {
  txt <- normalize_reference_text_r(full_text)
  if (!nzchar(txt)) {
    return(list(found = FALSE, start_index = NULL, reference_text = "", references = character(0), count = 0L, error = "Empty text"))
  }

  lines <- unlist(strsplit(txt, "\n", fixed = TRUE))
  start_line <- NA_integer_
  for (i in seq_along(lines)) {
    s <- tolower(trimws(lines[[i]]))
    if (grepl("^(?:[0-9]+[[:space:]]+)?references[[:space:]]*:?$", s, perl = TRUE) || grepl("^references[[:space:]]*:[[:space:]]*[0-9]*$", s, perl = TRUE)) {
      start_line <- i
      break
    }
  }
  if (is.na(start_line)) {
    tail_start <- max(1L, floor(length(lines) * 0.65))
    tail_lines <- lines[tail_start:length(lines)]
    numbered <- grepl("^\\s*(?:\\[[0-9]+\\]|\\([0-9]+\\)|[0-9]+[.、)\\]])\\s+", tail_lines, perl = TRUE)
    idx <- which(numbered)
    if (length(idx) >= 3) {
      start_line <- tail_start + idx[1] - 1L
    } else {
      return(list(found = FALSE, start_index = NULL, reference_text = "", references = character(0), count = 0L, error = "No references heading found by R fallback"))
    }
  }

  raw_lines <- lines[(start_line + if (grepl("(?i)^\\s*(?:references|reference|bibliography|literature cited)", lines[start_line], perl = TRUE)) 1L else 0L):length(lines)]
  if (length(raw_lines) == 0) {
    return(list(found = FALSE, start_index = start_line, reference_text = "", references = character(0), count = 0L, error = "References heading found but body is empty"))
  }

  entries <- character(0)
  current <- character(0)
  seen_ref <- FALSE
  end_heading_pat <- "^(figure legends?|tables?|strobe statement|checklist of items|oa_|supplemental digital content|acknowledg?ments?)\\b"

  for (line in raw_lines) {
    s <- strip_reference_noise_line_r(line)
    if (!nzchar(s)) next

    if (seen_ref && grepl(end_heading_pat, tolower(s), perl = TRUE)) {
      break
    }

    is_new_ref <- grepl("^[[:space:]]*(?:\\[[0-9]+\\]|\\([0-9]+\\)|[0-9]+[.])[[:space:]]+", s, perl = TRUE)
    if (is_new_ref) {
      seen_ref <- TRUE
      if (length(current) > 0) {
        entries <- c(entries, trimws(paste(current, collapse = " ")))
      }
      current <- s
    } else if (seen_ref) {
      current <- c(current, s)
    }
  }
  if (length(current) > 0) {
    entries <- c(entries, trimws(paste(current, collapse = " ")))
  }

  entries <- gsub("[[:space:]]+", " ", entries, perl = TRUE)
  entries <- sub("^\\[([0-9]+)\\][[:space:]]*", "\\1. ", entries, perl = TRUE)
  entries <- sub("^\\(([0-9]+)\\)[[:space:]]*", "\\1. ", entries, perl = TRUE)

  ref_text <- paste(raw_lines, collapse = "\n")
  list(found = length(entries) > 0, start_index = start_line, reference_text = ref_text, references = entries, count = as.integer(length(entries)), error = NULL)
}

clean_reference_for_coword_r <- function(ref) {
  s <- trimws(as.character(ref %||% ""))
  s <- sub("^[0-9]+[.][[:space:]]*", "", s, perl = TRUE)
  s <- gsub("(^|[^[:alnum:]_])doi[[:space:]]*:[[:space:]]*[^[:space:]]+", " ", s, ignore.case = TRUE, perl = TRUE)
  s <- gsub("(^|[^[:alnum:]_])PMID[[:space:]]*:[[:space:]]*[^[:space:]]+", " ", s, ignore.case = TRUE, perl = TRUE)
  s <- gsub("(^|[^[:alnum:]_])PMCID[[:space:]]*:[[:space:]]*[^[:space:]]+", " ", s, ignore.case = TRUE, perl = TRUE)
  s <- gsub("(^|[^[:alnum:]_])(?:URL|UTL|Available at)[[:space:]]*:[[:space:]]*[^[:space:]]+", " ", s, ignore.case = TRUE, perl = TRUE)
  s <- gsub("https?://[^[:space:]]+", " ", s, perl = TRUE)
  s <- gsub("\\([[:space:]]*Accessed[^)]*\\)", " ", s, ignore.case = TRUE, perl = TRUE)
  s <- gsub("[[:space:]]+", " ", s, perl = TRUE)
  trimws(s)
}

extract_reference_coword_rows_r <- function(full_text) {
  sec <- extract_reference_section_r(full_text)
  refs <- as.character(sec$references %||% character(0))
  if (length(refs) == 0) {
    return(tibble::tibble(ref_no = character(0), reference_raw = character(0), reference_clean = character(0)))
  }
  tibble::tibble(
    ref_no = as.character(seq_along(refs)),
    reference_raw = refs,
    reference_clean = vapply(refs, clean_reference_for_coword_r, character(1))
  )
}

expand_ama_citation_token_r <- function(token) {
  token <- gsub("[[:space:]]+", "", as.character(token %||% ""))
  if (!nzchar(token)) return(integer(0))
  parts <- unlist(strsplit(token, ",", fixed = TRUE))
  nums <- integer(0)
  for (part in parts) {
    if (grepl("^[0-9]+-[0-9]+$", part)) {
      ab <- as.integer(unlist(strsplit(part, "-", fixed = TRUE)))
      if (length(ab) == 2 && all(!is.na(ab))) {
        if (ab[1] <= ab[2]) nums <- c(nums, seq.int(ab[1], ab[2])) else nums <- c(nums, seq.int(ab[2], ab[1]))
      }
    } else if (grepl("^[0-9]+$", part)) {
      nums <- c(nums, as.integer(part))
    }
  }
  nums
}

check_sequential_ama_r <- function(full_text, ref_docs) {
  txt <- normalize_reference_text_r(full_text)
  lines <- unlist(strsplit(txt, "\n", fixed = TRUE))
  start_line <- NA_integer_
  for (i in seq_along(lines)) {
    s <- tolower(trimws(lines[[i]]))
    if (grepl("^(?:[0-9]+[[:space:]]+)?references[[:space:]]*:?$", s, perl = TRUE) || grepl("^references[[:space:]]*:[[:space:]]*[0-9]*$", s, perl = TRUE)) {
      start_line <- i
      break
    }
  }
  body_text <- if (is.na(start_line)) txt else paste(lines[seq_len(max(1, start_line - 1))], collapse = "\n")

  m <- gregexpr("\\[([0-9]+(?:[[:space:]]*[-,][[:space:]]*[0-9]+)*)\\]", body_text, perl = TRUE)
  starts <- as.integer(m[[1]])
  tokens <- if (length(starts) == 1 && starts[1] == -1) character(0) else regmatches(body_text, m)[[1]]

  hit_tbl <- tibble::tibble(
    hit_order = integer(0),
    token = character(0),
    expanded = character(0),
    numbers = character(0),
    start_pos = integer(0)
  )

  expanded_all <- integer(0)
  first_order <- integer(0)
  seen <- integer(0)

  if (length(tokens) > 0) {
    rows <- vector("list", length(tokens))
    for (i in seq_along(tokens)) {
      tok <- tokens[[i]]
      inner <- sub("^\\[(.*)\\]$", "\\1", tok, perl = TRUE)
      nums <- expand_ama_citation_token_r(inner)
      expanded_all <- c(expanded_all, nums)
      new_nums <- nums[!(nums %in% seen)]
      if (length(new_nums) > 0) {
        first_order <- c(first_order, new_nums)
        seen <- c(seen, new_nums)
      }
      rows[[i]] <- data.frame(
        hit_order = i,
        token = tok,
        expanded = paste(nums, collapse = ", "),
        numbers = paste(nums, collapse = ","),
        start_pos = starts[[i]],
        stringsAsFactors = FALSE
      )
    }
    hit_tbl <- tibble::as_tibble(do.call(rbind, rows))
  }

  cited_unique <- unique(expanded_all)
  ref_numbers <- suppressWarnings(as.integer(ref_docs$ref_no %||% integer(0)))
  ref_numbers <- ref_numbers[!is.na(ref_numbers)]

  ref_seq_tbl <- tibble::tibble(
    mention_order = seq_along(first_order),
    citation_no = first_order,
    expected_no = seq_along(first_order),
    sequential_ok = first_order == seq_along(first_order),
    exists_in_reference_list = first_order %in% ref_numbers
  )

  ref_tbl <- tibble::tibble(
    ref_no = ref_numbers,
    listed = TRUE,
    cited_in_text = ref_numbers %in% cited_unique
  )

  ref_numbering_ok <- length(ref_numbers) > 0 && identical(ref_numbers, seq_len(length(ref_numbers)))
  first_seq_ok <- length(first_order) == 0 || identical(first_order, seq_len(max(first_order)))
  missing_in_ref <- setdiff(cited_unique, ref_numbers)
  uncited_refs <- setdiff(ref_numbers, cited_unique)

  diag <- tibble::tribble(
    ~check, ~status, ~details,
    "In-text AMA citation patterns",
    if (nrow(hit_tbl) > 0) "OK" else "Warning",
    paste0("Found ", nrow(hit_tbl), " bracket-style AMA citation groups in the body text."),
    "Reference list numbering",
    if (ref_numbering_ok) "OK" else "Warning",
    if (length(ref_numbers) == 0) "No numbered reference list available." else paste0("Reference list numbers detected: ", length(ref_numbers), "."),
    "First appearance is sequential",
    if (first_seq_ok) "OK" else "Warning",
    if (length(first_order) == 0) "No in-text citations found before the reference section." else paste0("First-seen citation order: ", paste(first_order, collapse = ", ")),
    "All cited numbers exist in reference list",
    if (length(missing_in_ref) == 0) "OK" else "Warning",
    if (length(missing_in_ref) == 0) "All cited numbers were found in the reference list." else paste0("Missing from reference list: ", paste(missing_in_ref, collapse = ", ")),
    "Reference entries never cited in text",
    if (length(uncited_refs) == 0) "OK" else "Info",
    if (length(uncited_refs) == 0) "All reference entries were cited in text." else paste0("Uncited reference numbers: ", paste(utils::head(uncited_refs, 30), collapse = ", "), if (length(uncited_refs) > 30) " ..." else "")
  )

  list(
    diagnostics = diag,
    sequence = ref_seq_tbl,
    reference_list = ref_tbl,
    hits = hit_tbl
  )
}


empty_reference_network <- function() {
  list(
    nodes = data.frame(), edges = data.frame(), graph = NULL, cooc = data.frame(),
    final_edges = data.frame(), anno_top = data.frame(),
    aac = data.frame(metric = character(0), AAC = numeric(0)), diagnostics = data.frame()
  )
}

empty_reference_payload <- function() {
  list(
    documents = tibble::tibble(ref_no = integer(0), reference_raw = character(0)),
    coword_rows = tibble::tibble(ref_no = character(0), reference_raw = character(0), reference_clean = character(0)),
    diagnostics = tibble::tibble(check = "Reference analysis", status = "Info", details = "No reference analysis yet."),
    ama = list(
      diagnostics = tibble::tibble(check = "Sequential AMA", status = "Info", details = "No AMA check yet."),
      sequence = tibble::tibble(mention_order = integer(0), citation_no = integer(0), expected_no = integer(0), sequential_ok = logical(0), exists_in_reference_list = logical(0)),
      reference_list = tibble::tibble(ref_no = integer(0), listed = logical(0), cited_in_text = logical(0)),
      hits = tibble::tibble(hit_order = integer(0), token = character(0), expanded = character(0), numbers = character(0), start_pos = integer(0))
    ),
    network = empty_reference_network()
  )
}

docs_to_full_text <- function(docs) {
  if (is.null(docs)) return("")
  if (is.character(docs)) return(paste(docs, collapse = "\n"))
  if (is.data.frame(docs)) {
    preferred <- intersect(c("text", "content", "body", "document", "doc_text", "full_text"), names(docs))
    if (length(preferred) > 0) return(paste(as.character(docs[[preferred[1]]]), collapse = "\n"))
    chr_cols <- names(docs)[vapply(docs, is.character, logical(1))]
    if (length(chr_cols) > 0) return(paste(as.character(docs[[chr_cols[1]]]), collapse = "\n"))
  }
  paste(capture.output(utils::str(docs)), collapse = "\n")
}


read_docx_paragraphs <- function(path) {
  stopifnot(file.exists(path))
  td <- tempfile("docx_")
  dir.create(td, recursive = TRUE, showWarnings = FALSE)
  on.exit(unlink(td, recursive = TRUE, force = TRUE), add = TRUE)
  utils::unzip(path, files = "word/document.xml", exdir = td)
  xml_path <- file.path(td, "word", "document.xml")
  if (!file.exists(xml_path)) {
    return(tibble::tibble(doc_id = integer(0), text = character(0), source = character(0)))
  }
  x <- xml2::read_xml(xml_path)
  ns <- xml2::xml_ns(x)
  paras <- xml2::xml_find_all(x, ".//w:p", ns = ns)
  txt <- vapply(paras, function(p) {
    paste(xml2::xml_text(xml2::xml_find_all(p, ".//w:t", ns = ns)), collapse = "")
  }, character(1))
  txt <- trimws(txt)
  txt <- txt[nzchar(txt)]
  tibble::tibble(doc_id = seq_along(txt), text = txt, source = "docx_paragraph")
}

read_docx_text_xml <- function(path) {
  docs <- read_docx_paragraphs(path)
  if (nrow(docs) == 0) return("")
  paste(docs$text, collapse = "\n")
}

read_uploaded_documents <- function(path, ext, csv_text_col = NULL) {
  ext <- tolower(as.character(ext %||% ""))
  path <- as.character(path %||% "")
  if (!nzchar(path) || !file.exists(path)) stop("Uploaded file not found.")

  if (identical(ext, "pdf")) {
    pages <- tryCatch(pdftools::pdf_text(path), error = function(e) NULL)
    if (is.null(pages)) stop("Unable to read PDF text.")
    return(tibble::tibble(doc_id = seq_along(pages), text = as.character(pages)))
  }

  if (identical(ext, "txt")) {
    txt <- paste(readLines(path, warn = FALSE, encoding = "UTF-8"), collapse = "\n")
    return(tibble::tibble(doc_id = 1L, text = txt))
  }

  if (identical(ext, "csv")) {
    dat <- readr::read_csv(path, show_col_types = FALSE, progress = FALSE)
    if (nrow(dat) == 0) return(tibble::tibble(doc_id = integer(0), text = character(0)))
    col_nm <- csv_text_col %||% NULL
    if (is.null(col_nm) || !nzchar(col_nm) || !col_nm %in% names(dat)) {
      chr_cols <- names(dat)[vapply(dat, function(x) is.character(x) || is.factor(x), logical(1))]
      if (length(chr_cols) == 0) stop("CSV does not contain a usable text column.")
      col_nm <- chr_cols[1]
    }
    return(tibble::tibble(doc_id = seq_len(nrow(dat)), text = as.character(dat[[col_nm]])))
  }

  if (identical(ext, "docx")) {
    docs <- tryCatch(read_docx_paragraphs(path), error = function(e) tibble::tibble(doc_id = integer(0), text = character(0), source = character(0)))
    if (nrow(docs) == 0 || !any(nzchar(trimws(docs$text)))) stop("Unable to read DOCX text.")
    return(docs[, c("doc_id", "text"), drop = FALSE])
  }

  stop("Unsupported file type. Please upload a PDF, DOCX, TXT, or CSV file.")
}


pick_first_col <- function(df, candidates) {
  nm <- intersect(candidates, names(df))
  if (length(nm) == 0) return(NULL)
  nm[1]
}

extract_docx_reference_documents <- function(docs) {
  docs <- tibble::as_tibble(docs)
  if (nrow(docs) == 0 || !"text" %in% names(docs)) {
    return(tibble::tibble(ref_no = integer(0), reference_raw = character(0)))
  }
  paras <- trimws(as.character(docs$text))
  paras <- paras[nzchar(paras)]
  if (!length(paras)) return(tibble::tibble(ref_no = integer(0), reference_raw = character(0)))

  start_idx <- grep("(?i)^references$|^references[[:space:]]*[:：]?$|^參考文獻$|^参考文献$|^參考資料$|^引用文獻$", paras, perl = TRUE)
  if (!length(start_idx)) return(tibble::tibble(ref_no = integer(0), reference_raw = character(0)))
  start_idx <- start_idx[1] + 1L

  tail_paras <- paras[start_idx:length(paras)]
  end_rel <- grep("(?i)^figure legends?$|^figures legends?$|^圖例$|^figure legends[[:space:]]*[:：]?$", tail_paras, perl = TRUE)
  if (length(end_rel)) {
    tail_paras <- tail_paras[seq_len(max(1, end_rel[1] - 1L))]
  }
  tail_paras <- tail_paras[nzchar(tail_paras)]
  if (!length(tail_paras)) return(tibble::tibble(ref_no = integer(0), reference_raw = character(0)))

  is_ref_start <- function(x) grepl("^[0-9]+[.、)]([[:space:]]|$)", x, perl = TRUE)
  refs <- character(0)
  cur <- character(0)
  for (ln in tail_paras) {
    if (is_ref_start(ln)) {
      if (length(cur)) refs <- c(refs, paste(cur, collapse = " "))
      cur <- ln
    } else if (length(cur)) {
      cur <- c(cur, ln)
    }
  }
  if (length(cur)) refs <- c(refs, paste(cur, collapse = " "))
  refs <- trimws(gsub("[[:space:]]+", " ", refs, perl = TRUE))
  refs <- refs[nzchar(refs)]
  tibble::tibble(ref_no = seq_along(refs), reference_raw = refs)
}

build_reference_payload_from_docs <- function(docs, ext = "") {
  ext <- tolower(as.character(ext %||% ""))
  docs <- tibble::as_tibble(docs)
  full_text <- docs_to_full_text(docs)

  if (!identical(ext, "docx")) {
    return(build_reference_payload_from_text(full_text))
  }

  ref_docs0 <- extract_docx_reference_documents(docs)
  if (nrow(ref_docs0) == 0) {
    out <- build_reference_payload_from_text(full_text)
    out$diagnostics <- dplyr::bind_rows(
      tibble::tibble(check = "DOCX references", status = "Warning", details = "DOCX paragraph-based extraction found 0 references; fallback extractor used."),
      out$diagnostics
    )
    return(out)
  }

  parsed_entity_rows <- tryCatch(parse_reference_author_journal_rows(ref_docs0), error = function(e) tibble::tibble())
  if (nrow(parsed_entity_rows) > 0) {
    ref_docs <- parsed_entity_rows |>
      dplyr::group_by(ref_no, reference_raw) |>
      dplyr::summarise(
        authors = paste(unique(entity[entity_type == "author"]), collapse = "; "),
        journal = paste(unique(entity[entity_type == "journal"]), collapse = "; "),
        .groups = "drop"
      ) |>
      dplyr::arrange(suppressWarnings(as.integer(ref_no)))
  } else {
    ref_docs <- ref_docs0
  }

  diag <- tibble::tribble(
    ~check, ~status, ~details,
    "Reference section", "OK", paste0("DOCX paragraph-based extraction detected ", nrow(ref_docs0), " references."),
    "Reference rows", if (nrow(parsed_entity_rows) > 0) "OK" else "Warning", paste0("Reference author/journal rows: ", nrow(parsed_entity_rows)),
    "Reference documents", "OK", paste0("Reference documents: ", nrow(ref_docs))
  )

  ref_net <- build_reference_network_from_rows(ref_docs0, top_n = 20)
  if (is.null(ref_net$diagnostics) || !is.data.frame(ref_net$diagnostics)) ref_net$diagnostics <- tibble::tibble()
  if (nrow(ref_net$diagnostics) > 0) diag <- dplyr::bind_rows(diag, ref_net$diagnostics)
  ama <- check_sequential_ama_r(full_text, ref_docs)

  list(
    documents = ref_docs,
    coword_rows = parsed_entity_rows,
    diagnostics = diag,
    ama = ama,
    network = ref_net
  )
}

extract_manuscript_sections <- function(docs) {
  docs <- tibble::as_tibble(docs)
  paras <- trimws(as.character(docs$text %||% character(0)))
  paras <- paras[nzchar(paras)]
  full_text <- paste(paras, collapse = "\n")
  if (!length(paras)) return(list(title = "", abstract = "", keywords = character(0), highlights = character(0), sections_present = character(0), full_text = full_text))

  heading_patterns <- c(
    abstract = "(?i)^abstract$|^abstract[[:space:]]*[:：]?$|^摘要$",
    highlights = "(?i)^highlights$|^highlights[[:space:]]*[:：]?$|^亮點$",
    introduction = "(?i)^introduction$|^introduction[[:space:]]*[:：]?$|^前言$|^緒論$",
    methods = "(?i)^methods$|^methods[[:space:]]*[:：]?$|^method$|^materials and methods$|^方法$",
    results = "(?i)^results$|^results[[:space:]]*[:：]?$|^結果$",
    discussion = "(?i)^discussions$|^discussion$|^討論$",
    conclusion = "(?i)^conclusion$|^conclusions$|^結論$",
    declarations = "(?i)^declarations$",
    acknowledgments = "(?i)^acknowledg?ments$",
    references = "(?i)^references$|^references[[:space:]]*[:：]?$|^參考文獻$|^参考文献$",
    figure_legends = "(?i)^figure legends?$|^figures legends?$"
  )

  find_heading <- function(pattern) {
    idx <- grep(pattern, paras, perl = TRUE)
    if (length(idx)) idx[1] else NA_integer_
  }
  heading_idx <- lapply(heading_patterns, find_heading)
  heading_idx <- heading_idx[!is.na(unlist(heading_idx))]
  heading_pos <- sort(unlist(heading_idx))
  sections_present <- names(heading_idx)

  get_block_after <- function(name) {
    idx <- heading_idx[[name]]
    if (is.null(idx) || is.na(idx)) return("")
    nexts <- heading_pos[heading_pos > idx]
    end <- if (length(nexts)) nexts[1] - 1L else length(paras)
    if (end < idx + 1L) return("")
    paste(paras[(idx + 1L):end], collapse = "\n")
  }

  title_end <- if (length(heading_pos)) heading_pos[1] - 1L else min(6L, length(paras))
  title_candidates <- paras[seq_len(max(1L, title_end))]
  title_candidates <- title_candidates[!grepl("(?i)^(running title|word count|table:|figure:|keywords[[:space:]]*[:：]|highlights?[[:space:]]*[:：]|list of abbreviations|abstract[[:space:]]*[:：]?)", title_candidates, perl = TRUE)]
  title <- if (length(title_candidates)) title_candidates[1] else paras[1]

  kw <- split_author_keywords(full_text)
  highlights <- character(0)
  hi_block <- get_block_after("highlights")
  if (nzchar(hi_block)) {
    hi_lines <- trimws(unlist(strsplit(hi_block, "\n")))
    hi_lines <- hi_lines[nzchar(hi_lines)]
    highlights <- hi_lines[seq_len(min(3, length(hi_lines)))]
  }

  list(
    title = title,
    abstract = extract_abstract_text(full_text),
    keywords = kw,
    highlights = highlights,
    introduction = get_block_after("introduction"),
    methods = get_block_after("methods"),
    results = get_block_after("results"),
    discussion = get_block_after("discussion"),
    conclusion = get_block_after("conclusion"),
    references = get_block_after("references"),
    figure_legends = get_block_after("figure_legends"),
    sections_present = sections_present,
    full_text = full_text
  )
}

score_from_issue_count <- function(n_issues, n_words, tol_per_1000 = 2, floor_score = 0) {
  n_issues <- suppressWarnings(as.numeric(n_issues %||% 0))
  n_words <- suppressWarnings(as.numeric(n_words %||% 0))
  if (!is.finite(n_issues) || n_issues < 0) n_issues <- 0
  if (!is.finite(n_words) || n_words <= 0) return(0)
  rate <- (n_issues / n_words) * 1000
  score <- 100 - (rate / tol_per_1000) * 10
  score <- max(floor_score, min(100, round(score)))
  score
}

language_quality_breakdown <- function(full_text, abstract_text = "") {
  txt <- as.character(full_text %||% "")
  txt <- gsub("[\r\n]+", " ", txt, perl = TRUE)
  txt <- gsub("[[:space:]]+", " ", txt, perl = TRUE)
  txt <- trimws(txt)
  abs_txt <- as.character(abstract_text %||% "")

  sentence_split <- unlist(strsplit(txt, "(?<=[.!?])[[:space:]]+", perl = TRUE))
  sentence_split <- trimws(sentence_split)
  sentence_split <- sentence_split[nzchar(sentence_split)]

  total_words <- stringr::str_count(txt, "\\S+")
  if (!is.finite(total_words) || total_words <= 0) total_words <- 1

  long_sent_n <- sum(stringr::str_count(sentence_split, "[[:space:]]+") >= 35)
  repeated_word_n <- stringr::str_count(tolower(txt), "\\b([[:alpha:]]+)\\s+\\1\\b")
  space_before_punct_n <- stringr::str_count(txt, "[[:alnum:]][[:space:]]+[,;:]")
  repeated_punct_n <- stringr::str_count(txt, "[!?.,;:]{2,}")
  hedge_phrase_n <- stringr::str_count(
    tolower(txt),
    "\\b(in order to|due to the fact that|it should be noted that|it is important to note that)\\b"
  )

  typo_patterns <- c(
    "(?i)(^|[^[:alpha:]])fgure([^[:alpha:]]|$)",
    "(?i)(^|[^[:alpha:]])submision([^[:alpha:]]|$)",
    "(?i)(^|[^[:alpha:]])acheive([^[:alpha:]]|$)"
  )
  typo_hits <- sum(vapply(typo_patterns, function(pat) stringr::str_count(txt, pat), numeric(1)))

  abstract_words <- stringr::str_count(abs_txt, "\\S+")
  abstract_wording_n <- if (is.finite(abstract_words) && abstract_words > 0 && abstract_words < 80) 1 else 0

  grammar_issues <- as.integer(long_sent_n + space_before_punct_n + repeated_punct_n)
  spelling_issues <- as.integer(typo_hits)
  wording_issues <- as.integer(long_sent_n + repeated_word_n + hedge_phrase_n + abstract_wording_n)

  grammar_score <- score_from_issue_count(grammar_issues, total_words, tol_per_1000 = 2.5)
  spelling_score <- score_from_issue_count(spelling_issues, total_words, tol_per_1000 = 1.5)
  wording_score <- score_from_issue_count(wording_issues, total_words, tol_per_1000 = 3)
  overall_score <- round(0.4 * grammar_score + 0.3 * spelling_score + 0.3 * wording_score)

  weakest <- names(sort(c(grammar = grammar_score, spelling = spelling_score, wording = wording_score)))[1]
  language_note <- if (overall_score >= 90) {
    "Language quality is strong overall, with only minor polishing suggested."
  } else if (overall_score >= 75) {
    paste0("Language quality is generally good; prioritize ", weakest, " polishing before submission.")
  } else if (overall_score >= 60) {
    paste0("Language quality is fair; revision is recommended, especially for ", weakest, ".")
  } else {
    paste0("Language editing is recommended before submission, with the largest gains expected from ", weakest, " revision.")
  }

  list(
    overall = overall_score,
    note = language_note,
    badge = if (overall_score < 75) "Warning" else "Info",
    counts = list(
      long_sentences = long_sent_n,
      repeated_words = repeated_word_n,
      typo_hits = typo_hits,
      hedge_phrases = hedge_phrase_n,
      space_before_punct = space_before_punct_n,
      repeated_punct = repeated_punct_n,
      abstract_words = abstract_words
    ),
    subscores = tibble::tibble(
      aspect = c("Grammar", "Spelling", "Wording"),
      score = c(grammar_score, spelling_score, wording_score)
    )
  )
}

submission_readiness_from_docs <- function(docs, ext = "", checked_name = "Uploaded file", ref_payload = NULL) {
  ext <- tolower(as.character(ext %||% ""))
  secs <- extract_manuscript_sections(docs)
  full_text <- secs$full_text %||% docs_to_full_text(docs)
  ref_payload <- ref_payload %||% build_reference_payload_from_docs(docs, ext)
  ref_docs <- tibble::as_tibble(ref_payload$documents %||% data.frame())
  ama <- ref_payload$ama %||% list(sequential_ok = NA, citation_order = integer(0), missing_from_references = integer(0), uncited_references = integer(0))

  section_hits <- c(
    abstract = nzchar(trimws(secs$abstract %||% "")),
    introduction = nzchar(trimws(secs$introduction %||% "")),
    methods = nzchar(trimws(secs$methods %||% "")),
    results = nzchar(trimws(secs$results %||% "")),
    discussion = nzchar(trimws(secs$discussion %||% "")),
    conclusion = nzchar(trimws(secs$conclusion %||% "")),
    references = nrow(ref_docs) > 0
  )
  section_score <- round(100 * mean(section_hits), 0)

  lang_breakdown <- language_quality_breakdown(full_text, secs$abstract %||% "")
  lang_score <- lang_breakdown$overall
  lang_subscores <- tibble::as_tibble(lang_breakdown$subscores %||% tibble::tibble())

  tech_checks <- c(
    keywords = length(secs$keywords) > 0,
    figure_legends = nzchar(trimws(secs$figure_legends %||% "")),
    references = nrow(ref_docs) > 0,
    ama_seq = isTRUE(ama$sequential_ok)
  )
  tech_score <- round(100 * mean(tech_checks), 0)
  failed_n <- sum(!tech_checks)
  critical_passed <- sum(tech_checks)

  status_label <- if (section_score >= 85 && tech_score >= 75) "Ready" else if (section_score >= 60) "Moderate revisions needed" else "Major revisions needed"

  manuscript_points <- unique(c(
    if (nzchar(trimws(secs$title %||% ""))) paste0("Title detected: ", secs$title),
    if (length(secs$keywords) > 0) paste0("Keywords detected: ", paste(utils::head(secs$keywords, 5), collapse = "; ")),
    if (length(secs$highlights) > 0) paste0("Highlights available: ", length(secs$highlights), " key points."),
    if (nrow(ref_docs) > 0) paste0("Reference list extracted: ", nrow(ref_docs), " entries."),
    if (sum(!section_hits) > 0) paste0("Missing or weak sections: ", paste(names(section_hits)[!section_hits], collapse = ", "))
  ))

  language_points <- unique(c(
    paste0("Grammar: ", lang_subscores$score[match("Grammar", lang_subscores$aspect)] %||% 0, "/100."),
    paste0("Spelling: ", lang_subscores$score[match("Spelling", lang_subscores$aspect)] %||% 0, "/100."),
    paste0("Wording: ", lang_subscores$score[match("Wording", lang_subscores$aspect)] %||% 0, "/100."),
    if ((lang_breakdown$counts$typo_hits %||% 0) > 0) paste0("Potential typos detected: ", lang_breakdown$counts$typo_hits, "."),
    if ((lang_breakdown$counts$long_sentences %||% 0) > 0) paste0("Long sentences needing simplification: ", lang_breakdown$counts$long_sentences, "."),
    if ((lang_breakdown$counts$repeated_words %||% 0) > 0) paste0("Repeated words detected: ", lang_breakdown$counts$repeated_words, "."),
    if (nzchar(trimws(secs$abstract %||% ""))) paste0("Abstract length: ", lang_breakdown$counts$abstract_words %||% 0, " words (approx.).")
  ))

  technical_points <- unique(c(
    paste0("Technical checks passed: ", critical_passed, "/", length(tech_checks), "."),
    if (nrow(ref_docs) > 0) "DOCX/PDF reference extraction used manuscript structure rather than a flattened text scan.",
    if (!isTRUE(ama$sequential_ok)) "In-text citation order or reference matching may still need manual checking.",
    if (!tech_checks[["figure_legends"]]) "Figure legends section not clearly detected."
  ))

  diag_table <- tibble::tibble(
    aspect = c("Manuscript Status", "Language Quality", "Technical Compliance"),
    score = c(section_score, lang_score, tech_score),
    key_check = c(
      paste(names(section_hits)[section_hits], collapse = ", "),
      paste(language_points, collapse = " "),
      paste(technical_points, collapse = " ")
    )
  )

  list(
    checked_name = checked_name,
    status_label = status_label,
    overview = if (status_label == "Ready") "The uploaded manuscript passed the current structural review pass with only minor follow-up needed." else "The uploaded manuscript was parsed and reviewed. Please address the flagged structural, language, or technical points before submission.",
    language_overall = lang_score,
    language_suggestions = sum(unlist(lang_breakdown$counts[c("typo_hits", "long_sentences", "repeated_words")]) %||% 0),
    language_note = lang_breakdown$note,
    language_badge = lang_breakdown$badge,
    language_subscores = lang_subscores,
    failed_n = failed_n,
    total_checks = length(tech_checks),
    critical_passed = critical_passed,
    manuscript_points = manuscript_points,
    language_points = language_points,
    technical_points = technical_points,
    key_points = unique(c(utils::head(secs$highlights, 3), utils::head(secs$keywords, 5))),
    aspect_scores = tibble::tibble(aspect = c("Manuscript Status", "Language Quality", "Technical Compliance"), score = c(section_score, lang_score, tech_score)),
    diagnostics = diag_table
  )
}

compute_aac_scalar <- function(x) {
  x <- suppressWarnings(as.numeric(x))
  x <- x[is.finite(x) & x > 0]
  if (length(x) < 3) return(NA_real_)
  x <- sort(x, decreasing = TRUE)
  A <- x[1]; B <- x[2]; C <- x[3]
  if (B <= 0) return(NA_real_)
  r <- (A * C) / (B^2)
  r / (1 + r)
}

ensure_ss_astar_nodes <- function(nodes) {
  nd <- tibble::as_tibble(nodes)
  if (nrow(nd) == 0) return(nd)
  if (!"ss" %in% names(nd)) nd$ss <- 0
  nd$ss <- suppressWarnings(as.numeric(nd$ss))
  nd$ss[!is.finite(nd$ss)] <- 0
  if (!"a_star" %in% names(nd)) {
    if ("AAC" %in% names(nd)) {
      nd$a_star <- suppressWarnings(as.numeric(nd$AAC))
    } else if ("value" %in% names(nd)) {
      vv <- suppressWarnings(as.numeric(nd$value))
      vv[!is.finite(vv)] <- 0
      vmax <- max(vv, na.rm = TRUE)
      nd$a_star <- if (is.finite(vmax) && vmax > 0) vv / vmax else 0
    } else if ("freq" %in% names(nd)) {
      vv <- suppressWarnings(as.numeric(nd$freq))
      vv[!is.finite(vv)] <- 0
      vmax <- max(vv, na.rm = TRUE)
      nd$a_star <- if (is.finite(vmax) && vmax > 0) vv / vmax else 0
    } else {
      nd$a_star <- 0
    }
  }
  nd$a_star <- suppressWarnings(as.numeric(nd$a_star))
  nd$a_star[!is.finite(nd$a_star)] <- 0
  if (!"cluster" %in% names(nd)) nd$cluster <- 1
  if (!"label" %in% names(nd)) {
    if ("name" %in% names(nd)) nd$label <- as.character(nd$name) else if ("id" %in% names(nd)) nd$label <- as.character(nd$id) else nd$label <- as.character(seq_len(nrow(nd)))
  }
  nd
}

plot_ss_astar_kano <- function(nodes, title = "SS vs a* Kano") {
  nd <- ensure_ss_astar_nodes(nodes)
  validate(need(nrow(nd) > 0, "No SS/a* Kano data available."))
  xv <- nd$a_star
  yv <- nd$ss
  xcut <- stats::median(xv[is.finite(xv)], na.rm = TRUE)
  ycut <- stats::median(yv[is.finite(yv)], na.rm = TRUE)
  if (!is.finite(xcut)) xcut <- 0.5
  if (!is.finite(ycut)) ycut <- 0
  ggplot2::ggplot(nd, ggplot2::aes(x = a_star, y = ss, color = factor(cluster), label = label)) +
    ggplot2::geom_vline(xintercept = xcut, linetype = 2, color = "firebrick") +
    ggplot2::geom_hline(yintercept = ycut, linetype = 2, color = "firebrick") +
    ggplot2::geom_point(size = 2.8, alpha = 0.9) +
    ggplot2::geom_text(size = 3, vjust = -0.5, check_overlap = TRUE) +
    ggplot2::labs(title = title, x = "a*", y = "SS", color = "Cluster") +
    ggplot2::theme_minimal(base_size = 13)
}

submission_readiness_from_result <- function(res) {
  diag <- tibble::as_tibble(res$overall$diagnostics %||% data.frame())
  docs <- tibble::as_tibble(res$overall$documents %||% data.frame())
  checked_name <- if (nrow(docs) > 0 && "name" %in% names(docs)) as.character(docs$name[[1]]) else "Uploaded file"
  failed_n <- if (nrow(diag) > 0) sum(grepl("warning|error|failed", tolower(apply(diag, 1, paste, collapse=' ')))) else 0
  critical_passed <- if (nrow(diag) > 0) sum(grepl("ok|passed", tolower(apply(diag, 1, paste, collapse=' ')))) else 0
  status_label <- if (failed_n == 0) "Ready" else if (failed_n <= 4) "Moderate revisions needed" else "Major revisions needed"
  lang_suggestions <- nrow(tibble::as_tibble(res$main$tfidf_detail %||% data.frame()))
  lang_badge <- if (lang_suggestions > 500) "Warning" else "Info"
  list(
    checked_name = checked_name,
    status_label = status_label,
    overview = if (failed_n == 0) "No major technical issues detected in the current pass." else "Manuscript needs improvements. Address flagged issues to enhance your readiness.",
    language_overall = 0,
    language_suggestions = lang_suggestions,
    language_note = if (lang_suggestions > 500) "Readability needs major improvement" else "Language load appears manageable",
    language_badge = lang_badge,
    language_subscores = tibble::tibble(aspect = c("Grammar", "Spelling", "Wording"), score = c(0, 0, 0)),
    failed_n = failed_n,
    total_checks = max(1, nrow(diag)),
    critical_passed = critical_passed,
    manuscript_points = character(0),
    language_points = character(0),
    technical_points = character(0),
    key_points = character(0),
    aspect_scores = tibble::tibble(aspect = c("Manuscript Status", "Language Quality", "Technical Compliance"), score = c(0, 0, 0)),
    diagnostics = tibble::tibble()
  )
}

render_submission_report_ui <- function(x) {
  card_style <- "padding:18px 18px 14px 18px;border-radius:12px;background:#f6f7fb;border:1px solid #eceff5;min-height:220px;"
  hdr_badge <- function(txt) tags$span(style='float:right;background:#f3d98b;color:#6b4a00;font-size:11px;font-weight:700;padding:2px 8px;border-radius:6px;', txt)
  bulletize <- function(items) {
    items <- unique(trimws(as.character(items %||% character(0))))
    items <- items[nzchar(items)]
    if (!length(items)) return(tags$p(style='color:#5a6d89;','No comments generated yet.'))
    tags$ul(lapply(items, tags$li), style='padding-left:20px;margin-bottom:0;')
  }
  render_subscores <- function(tbl) {
    tbl <- tibble::as_tibble(tbl %||% tibble::tibble())
    if (nrow(tbl) == 0) return(NULL)
    tags$div(
      style='margin:10px 0 12px 0;',
      lapply(seq_len(nrow(tbl)), function(i) {
        nm <- as.character(tbl$aspect[[i]] %||% '')
        sc <- suppressWarnings(as.numeric(tbl$score[[i]] %||% 0))
        tags$div(
          style='margin-bottom:8px;',
          tags$div(
            style='display:flex;justify-content:space-between;font-size:13px;font-weight:700;',
            tags$span(nm),
            tags$span(sprintf('%s/100', round(sc)))
          ),
          tags$div(
            style='height:7px;background:#edf1f6;border-radius:999px;overflow:hidden;',
            tags$div(style=sprintf('height:7px;width:%s%%;background:#2f6fd6;', max(0, min(100, sc))))
          )
        )
      })
    )
  }
  aspect_scores <- tibble::as_tibble(x$aspect_scores %||% tibble::tibble())
  if (nrow(aspect_scores) == 0) {
    aspect_scores <- tibble::tibble(aspect = c("Manuscript Status", "Language Quality", "Technical Compliance"), score = c(0, 0, 0))
  }
  score_of <- function(name) {
    idx <- match(name, aspect_scores$aspect)
    if (is.na(idx)) return(0)
    aspect_scores$score[[idx]]
  }
  progress_bar <- function(label, score, color) {
    tags$div(style='margin-bottom:10px;',
      tags$div(style='display:flex;justify-content:space-between;font-weight:700;', tags$span(label), tags$span(sprintf('%s/100', round(score)))),
      tags$div(style='height:10px;background:#edf1f6;border-radius:999px;overflow:hidden;',
        tags$div(style=sprintf('height:10px;width:%s%%;background:%s;', max(0,min(100,score)), color))
      )
    )
  }
  htmltools::tagList(
    htmltools::div(style='background:#eef3fb;border:1px solid #d9e3f2;padding:18px 20px;border-radius:0;margin-bottom:18px;',
      htmltools::tags$h2(style='margin:0 0 8px 0;color:#0d2f66;font-size:34px;font-weight:800;', 'SUBMISSION READINESS REPORT'),
      htmltools::div(style='color:#173f6b;font-size:15px;',
        htmltools::tags$strong('Checked'), ' ', x$checked_name, '  |  ', htmltools::tags$strong('For'), ' Submission review upload')
    ),
    htmltools::tags$h3('Summary'),
    htmltools::div(style='display:flex;gap:14px;flex-wrap:wrap;',
      htmltools::div(style=paste0(card_style,'background:#f7edc9;border-color:#d19d33;flex:1 1 260px;'),
        htmltools::tags$h4(style='margin-top:0;', 'Manuscript Status'),
        htmltools::div(style='display:inline-block;background:#b47700;color:white;font-weight:800;padding:6px 12px;border-radius:8px;margin-bottom:12px;', toupper(x$status_label)),
        htmltools::tags$p(htmltools::tags$strong('Overview')),
        htmltools::tags$p(x$overview),
        htmltools::tags$div(style='font-weight:700;margin-top:8px;', 'Key points'),
        bulletize(x$manuscript_points)
      ),
      htmltools::div(style=paste0(card_style,'flex:1 1 220px;'),
        hdr_badge(toupper(x$language_badge)),
        htmltools::tags$h4(style='margin-top:0;', 'Language Quality'),
        htmltools::div(style='font-size:42px;font-weight:800;color:#0d2f66;line-height:1.1;', sprintf('%s/100', round(x$language_overall %||% score_of('Language Quality')))),
        htmltools::div(style='color:#5a6d89;margin-bottom:12px;', 'assessed by grammar, spelling, and wording'),
        htmltools::div(style='background:#f6e3a8;padding:8px 10px;border-radius:8px;font-weight:700;color:#6b5a19;margin-bottom:8px;', x$language_note),
        render_subscores(x$language_subscores),
        bulletize(x$language_points)
      ),
      htmltools::div(style=paste0(card_style,'flex:1 1 220px;'),
        hdr_badge('WARNING'),
        htmltools::tags$h4(style='margin-top:0;', 'Technical Compliance'),
        htmltools::div(style='font-size:42px;font-weight:800;color:#0d2f66;line-height:1.1;', x$failed_n),
        htmltools::div(style='color:#5a6d89;margin-bottom:12px;', sprintf('Failed out of %s total checks', x$total_checks)),
        htmltools::div(style='background:#d8f2db;padding:8px 10px;border-radius:8px;font-weight:700;color:#146b2e;margin-bottom:8px;', sprintf('Critical checks passed: %s', x$critical_passed)),
        bulletize(x$technical_points)
      )
    ),
    tags$div(style='margin-top:18px;padding:16px;border:1px solid #eceff5;border-radius:12px;background:#ffffff;',
      tags$h4(style='margin-top:0;','Score snapshot'),
      progress_bar('Manuscript Status', score_of('Manuscript Status'), '#b47700'),
      progress_bar('Language Quality', score_of('Language Quality'), '#2f6fd6'),
      progress_bar('Technical Compliance', score_of('Technical Compliance'), '#24945c')
    ),
    tags$div(style='margin-top:18px;padding:16px;border:1px solid #eceff5;border-radius:12px;background:#ffffff;',
      tags$h4(style='margin-top:0;','Manuscript key points extracted'),
      bulletize(x$key_points)
    )
  )
}

sanitize_reference_term <- function(x) {
  x <- as.character(x %||% "")
  x <- gsub("https?://[^[:space:]]+", " ", x, perl = TRUE)
  x <- gsub("(^|[^[:alnum:]_])doi[[:space:]]*:?[[:space:]]*[^[:space:]]+", " ", x, ignore.case = TRUE, perl = TRUE)
  x <- gsub("[[:space:]]+", " ", x, perl = TRUE)
  trimws(x)
}

parse_reference_author_journal_rows <- function(ref_rows) {
  ref_rows <- tibble::as_tibble(ref_rows)
  if (nrow(ref_rows) == 0) {
    return(tibble::tibble(
      ref_no = character(0),
      reference_raw = character(0),
      authors = character(0),
      journal = character(0),
      entity_type = character(0),
      entity = character(0)
    ))
  }

  norm_entity <- function(x) {
    x <- sanitize_reference_term(x)
    x <- gsub("^[[:punct:][:space:]]+|[[:punct:][:space:]]+$", "", x, perl = TRUE)
    x <- gsub("[[:space:]]+", " ", x, perl = TRUE)
    trimws(x)
  }

  split_authors <- function(x) {
    x <- gsub("\\bet al\\b.*$", "", x, ignore.case = TRUE, perl = TRUE)
    parts <- unlist(strsplit(x, ","))
    parts <- trimws(parts)
    parts <- parts[nzchar(parts)]
    parts <- parts[nchar(parts) >= 2]
    unique(parts)
  }

  parse_one <- function(ref_no, raw) {
    ref <- as.character(raw %||% "")
    ref <- gsub("^[[:space:]]*[0-9]+[.、)\\]]?[[:space:]]*", "", ref, perl = TRUE)
    ref <- gsub("[[:space:]]+", " ", ref, perl = TRUE)
    ref <- trimws(ref)
    parts <- unlist(strsplit(ref, "\\.[[:space:]]+", perl = TRUE))
    parts <- trimws(parts)
    parts <- parts[nzchar(parts)]

    authors_seg <- if (length(parts) >= 1) parts[1] else ""
    journal_seg <- ""
    if (length(parts) >= 3) {
      journal_seg <- parts[3]
    } else {
      rem <- sub("^[^.]+\\.[[:space:]]*[^.]+\\.[[:space:]]*", "", ref, perl = TRUE)
      rem <- sub("[[:space:]]*(19|20)[0-9]{2}.*$", "", rem, perl = TRUE)
      journal_seg <- rem
    }

    authors_seg <- norm_entity(authors_seg)
    journal_seg <- norm_entity(journal_seg)

    authors_vec <- split_authors(authors_seg)
    if (length(authors_vec) == 0 && nzchar(authors_seg)) authors_vec <- authors_seg

    rows <- list()
    if (length(authors_vec) > 0) {
      rows[[length(rows) + 1]] <- tibble::tibble(
        ref_no = as.character(ref_no),
        reference_raw = raw,
        authors = authors_seg,
        journal = journal_seg,
        entity_type = "author",
        entity = authors_vec
      )
    }
    if (nzchar(journal_seg)) {
      rows[[length(rows) + 1]] <- tibble::tibble(
        ref_no = as.character(ref_no),
        reference_raw = raw,
        authors = authors_seg,
        journal = journal_seg,
        entity_type = "journal",
        entity = journal_seg
      )
    }
    dplyr::bind_rows(rows)
  }

  dplyr::bind_rows(lapply(seq_len(nrow(ref_rows)), function(i) parse_one(ref_rows$ref_no[[i]] %||% i, ref_rows$reference_raw[[i]])))
}

build_reference_network_from_rows <- function(ref_rows, top_n = 20, min_term_freq = 1, min_edge_weight = 1) {
  ref_rows <- tibble::as_tibble(ref_rows)
  empty_net <- empty_reference_network()
  if (nrow(ref_rows) == 0 || !"reference_raw" %in% names(ref_rows)) return(empty_net)

  ent_rows <- parse_reference_author_journal_rows(ref_rows)
  if (nrow(ent_rows) == 0) return(empty_net)

  ent_rows <- ent_rows |>
    dplyr::mutate(entity = trimws(entity)) |>
    dplyr::filter(nzchar(entity))

  node_freq <- ent_rows |>
    dplyr::count(entity_type, entity, name = "freq") |>
    dplyr::filter(freq >= min_term_freq) |>
    dplyr::arrange(dplyr::desc(freq), entity_type, entity) |>
    dplyr::mutate(entity_id = paste0(entity_type, "::", entity))
  if (nrow(node_freq) == 0) return(empty_net)

  ent_rows2 <- ent_rows |>
    dplyr::inner_join(node_freq[, c("entity_type", "entity", "entity_id")], by = c("entity_type", "entity"))

  pair_list <- lapply(split(ent_rows2[, c("entity", "entity_type", "entity_id")], ent_rows2$ref_no), function(df) {
    df <- unique(df)
    if (nrow(df) < 2) return(NULL)
    cmb <- utils::combn(seq_len(nrow(df)), 2)
    tibble::tibble(
      from = df$entity_id[cmb[1, ]],
      to = df$entity_id[cmb[2, ]],
      from_label = df$entity[cmb[1, ]],
      to_label = df$entity[cmb[2, ]],
      from_type = df$entity_type[cmb[1, ]],
      to_type = df$entity_type[cmb[2, ]]
    )
  })
  raw_edges <- dplyr::bind_rows(pair_list)

  cooc <- if (!is.null(raw_edges) && nrow(raw_edges) > 0) {
    raw_edges |>
      dplyr::count(from, to, from_label, to_label, from_type, to_type, name = "weight") |>
      dplyr::arrange(dplyr::desc(weight), from, to)
  } else {
    tibble::tibble(from = character(0), to = character(0), from_label = character(0), to_label = character(0), from_type = character(0), to_type = character(0), weight = numeric(0))
  }

  # If no edges exist, keep top entities as isolated nodes.
  if (nrow(cooc) == 0) {
    nodes <- node_freq |>
      dplyr::slice_head(n = min(top_n, nrow(node_freq))) |>
      dplyr::mutate(cluster = seq_len(dplyr::n())) |>
      dplyr::transmute(id = entity_id, label = entity, value = freq, title = paste0(entity, " (", entity_type, ", ", freq, ")"), cluster = cluster, freq = freq, ss = NA_real_, type = entity_type)
    aac_tbl <- nodes |>
      dplyr::group_by(cluster) |>
      dplyr::summarise(SS = NA_real_, AAC = compute_aac_scalar(freq), n = dplyr::n(), .groups = "drop")
    nodes <- nodes |>
      dplyr::left_join(aac_tbl[, c("cluster", "AAC")], by = "cluster")
    return(list(nodes = nodes, edges = tibble::tibble(), graph = NULL, cooc = cooc, final_edges = tibble::tibble(), anno_top = node_freq |> dplyr::slice_head(n = min(top_n, nrow(node_freq))), aac = aac_tbl, diagnostics = tibble::tibble(check = "Reference network", status = "Info", details = "Only isolated author/journal nodes available after parsing.")))
  }

  # Initial clustering from raw co-occurrence graph.
  g0 <- igraph::graph_from_data_frame(cooc[, c("from", "to", "weight")], directed = FALSE,
                                      vertices = node_freq |>
                                        dplyr::transmute(name = entity_id, label = entity, value = freq, type = entity_type))
  memb0 <- rep(1L, igraph::gorder(g0))
  names(memb0) <- igraph::V(g0)$name
  if (igraph::ecount(g0) > 0 && igraph::gorder(g0) > 2) {
    cl0 <- tryCatch(igraph::cluster_louvain(g0, weights = igraph::E(g0)$weight), error = function(e) NULL)
    if (!is.null(cl0)) memb0 <- igraph::membership(cl0)
  }

  nodes0 <- tibble::tibble(entity_id = names(memb0), cluster = as.integer(memb0)) |>
    dplyr::left_join(node_freq, by = c("entity_id" = "entity_id")) |>
    dplyr::mutate(id = entity_id, label = entity, value = freq, title = paste0(entity, " (", entity_type, ", ", freq, ")"), ss = NA_real_, type = entity_type) |>
    safe_select_existing(c("id", "label", "value", "title", "type", "cluster", "freq", "ss"), defaults = list(id = character(), label = character(), value = numeric(), title = character(), type = character(), cluster = integer(), freq = numeric(), ss = numeric()))
  nodes0 <- compute_node_ss_from_graph(nodes0, cooc |> dplyr::transmute(from = from, to = to, weight = weight, width = pmax(1, weight), arrows = "to", title = paste0(from, " -- ", to, " (", weight, ")")))

  # Top-20 major sampling: keep strongest nodes by frequency then silhouette.
  nodes_top_n <- min(top_n, nrow(nodes0))
  nodes_top <- nodes0 |>
    dplyr::mutate(ss_rank = dplyr::if_else(is.na(ss), -999, ss)) |>
    dplyr::arrange(dplyr::desc(freq), dplyr::desc(ss_rank), label) |>
    dplyr::slice_head(n = nodes_top_n)

  # Single-link follower -> leader inside each cluster.
  leaders <- nodes_top |>
    dplyr::group_by(cluster) |>
    dplyr::arrange(dplyr::desc(freq), dplyr::desc(ss_rank), label, .by_group = TRUE) |>
    dplyr::slice_head(n = 1) |>
    dplyr::ungroup() |>
    dplyr::transmute(cluster, leader = id)

  nodes_top2 <- nodes_top |>
    dplyr::left_join(leaders, by = "cluster")

  final_edges <- nodes_top2 |>
    dplyr::filter(id != leader) |>
    dplyr::transmute(
      from = id,
      to = leader,
      weight = 1,
      width = 1,
      arrows = "to",
      title = paste0(id, " -> ", leader)
    )

  if (nrow(final_edges) == 0 && nrow(nodes_top2) >= 2) {
    # fallback tiny chain so the graph is not empty
    final_edges <- tibble::tibble(
      from = nodes_top2$id[-nrow(nodes_top2)],
      to = nodes_top2$id[-1],
      weight = 1,
      width = 1,
      arrows = "to",
      title = paste0(nodes_top2$id[-nrow(nodes_top2)], " -> ", nodes_top2$id[-1])
    )
  }

  # Raw cooc restricted to top sampled nodes only for inspection.
  keep_ids <- nodes_top2$id
  cooc_top <- cooc |>
    dplyr::filter(from %in% keep_ids, to %in% keep_ids) |>
    dplyr::transmute(from = from, to = to, from_label = from_label, to_label = to_label, from_type = from_type, to_type = to_type, weight = weight)

  nodes <- nodes_top2 |>
    safe_select_existing(c("id", "label", "value", "title", "type", "cluster", "freq", "ss"), defaults = list(id = character(), label = character(), value = numeric(), title = character(), type = character(), cluster = integer(), freq = numeric(), ss = numeric()))
  nodes <- compute_node_ss_from_graph(nodes, final_edges)

  aac_tbl <- nodes |>
    dplyr::group_by(cluster) |>
    dplyr::summarise(SS = mean(ss, na.rm = TRUE), AAC = compute_aac_scalar(freq), n = dplyr::n(), .groups = "drop")
  nodes <- nodes |>
    dplyr::left_join(aac_tbl[, c("cluster", "AAC")], by = "cluster")

  anno_top <- nodes |>
    dplyr::arrange(dplyr::desc(freq), label) |>
    dplyr::transmute(entity_type = type, entity = label, freq, cluster, ss, AAC)

  diag <- tibble::tribble(
    ~check, ~status, ~details,
    "Reference nodes", if (nrow(nodes) > 0) "OK" else "Warning", paste0("Top sampled author/journal nodes kept in final network: ", nrow(nodes)),
    "Reference raw edges", if (nrow(cooc_top) > 0) "OK" else "Warning", paste0("Raw co-occurrence edges among top sampled nodes: ", nrow(cooc_top)),
    "Reference final edges", if (nrow(final_edges) > 0) "OK" else "Warning", paste0("Single-link follower-to-leader final relations: ", nrow(final_edges))
  )

  list(nodes = nodes, edges = final_edges, graph = NULL, cooc = cooc_top, final_edges = final_edges, anno_top = anno_top, aac = aac_tbl, diagnostics = diag)
}


compute_node_ss_from_graph <- function(nodes, edges) {
  nd <- tibble::as_tibble(nodes)
  ed <- tibble::as_tibble(edges)
  if (nrow(nd) == 0) return(nd)
  if (!"ss" %in% names(nd)) nd$ss <- NA_real_
  if (nrow(ed) == 0 || !all(c("from","to") %in% names(ed)) || !"cluster" %in% names(nd)) return(nd)

  keep_ids <- as.character(nd$id %||% nd$label %||% nd$name)
  keep_ids <- keep_ids[nzchar(keep_ids)]
  if (length(keep_ids) < 3) return(nd)

  ed2 <- ed[ed$from %in% keep_ids & ed$to %in% keep_ids, , drop = FALSE]
  if (nrow(ed2) == 0) return(nd)
  w <- if ("weight" %in% names(ed2)) suppressWarnings(as.numeric(ed2$weight)) else rep(1, nrow(ed2))
  w[!is.finite(w) | w <= 0] <- 1

  g <- tryCatch(igraph::graph_from_data_frame(data.frame(from = ed2$from, to = ed2$to, weight = w), directed = FALSE, vertices = data.frame(name = keep_ids)), error = function(e) NULL)
  if (is.null(g)) return(nd)

  d <- tryCatch(igraph::distances(g, v = keep_ids, to = keep_ids, weights = 1 / pmax(igraph::E(g)$weight, 1)), error = function(e) NULL)
  if (is.null(d)) {
    d <- tryCatch(igraph::distances(g, v = keep_ids, to = keep_ids, weights = NA), error = function(e) NULL)
  }
  if (is.null(d)) return(nd)
  d[!is.finite(d)] <- max(d[is.finite(d)], na.rm = TRUE) + 1

  memb <- nd$cluster[match(keep_ids, nd$id)]
  if (length(unique(stats::na.omit(memb))) < 2) return(nd)
  ss_obj <- tryCatch(cluster::silhouette(as.integer(factor(memb)), stats::as.dist(d)), error = function(e) NULL)
  if (is.null(ss_obj)) return(nd)
  ss_vec <- ss_obj[, "sil_width"]
  nd$ss[match(keep_ids, nd$id)] <- as.numeric(ss_vec)
  nd
}



.make_ssplot_name_vec <- function(nodes) {
  nd <- tibble::as_tibble(nodes)
  if ("name" %in% names(nd)) return(trimws(as.character(nd$name)))
  if ("label" %in% names(nd)) return(trimws(as.character(nd$label)))
  trimws(as.character(nd$id %||% seq_len(nrow(nd))))
}

.make_ssplot_cluster_vec <- function(nodes) {
  nd <- tibble::as_tibble(nodes)
  if ("carac" %in% names(nd)) return(suppressWarnings(as.integer(as.character(nd$carac))))
  if ("cluster" %in% names(nd)) return(suppressWarnings(as.integer(as.character(nd$cluster))))
  rep(1L, nrow(nd))
}

.compute_ssplot_results <- function(sil_df, edges = NULL) {
  sil_df <- tibble::as_tibble(sil_df)
  cls <- sort(unique(stats::na.omit(as.integer(sil_df$carac))))
  if (!length(cls)) cls <- 1L
  freq_tab <- table(factor(sil_df$carac, levels = cls))
  pk <- as.numeric(freq_tab) / max(1, sum(freq_tab))
  D_overall <- 1 - sum(pk^2)
  Dmax_over <- if (length(cls) >= 1) 1 - 1 / length(cls) else NA_real_

  get_edges <- function(edges) {
    if (is.null(edges) || !is.data.frame(edges) || !nrow(edges)) {
      return(tibble::tibble(from = character(0), to = character(0), w = numeric(0)))
    }
    ed <- tibble::as_tibble(edges)
    from_col <- c("from", "Leader", "leader", "source")[c("from", "Leader", "leader", "source") %in% names(ed)][1]
    to_col   <- c("to", "follower", "Follower", "target")[c("to", "follower", "Follower", "target") %in% names(ed)][1]
    w_col    <- c("weight", "WCD", "width", "value")[c("weight", "WCD", "width", "value") %in% names(ed)][1]
    if (is.na(from_col) || is.na(to_col)) return(tibble::tibble(from = character(0), to = character(0), w = numeric(0)))
    out <- tibble::tibble(
      from = trimws(as.character(ed[[from_col]])),
      to   = trimws(as.character(ed[[to_col]])),
      w    = if (!is.na(w_col)) suppressWarnings(as.numeric(ed[[w_col]])) else 1
    )
    out$w[!is.finite(out$w)] <- 1
    out <- out |> dplyr::filter(nzchar(from), nzchar(to), from != to)
    out
  }

  ed <- get_edges(edges)
  if (!nrow(ed)) {
    out <- tibble::tibble(
      Cluster = c("OVERALL", paste0("C", cls)),
      SS = c(mean(sil_df$sil_width, na.rm = TRUE), vapply(cls, function(cc) mean(sil_df$sil_width[sil_df$carac == cc], na.rm = TRUE), numeric(1))),
      Qw = 0,
      Qu = 0,
      D_GiniSimpson = c(D_overall, rep(NA_real_, length(cls))),
      Q_over_D = c(0, rep(NA_real_, length(cls))),
      OneMinus_1_over_k = c(Dmax_over, rep(NA_real_, length(cls))),
      Q_over_Dmax_eff = c(0, rep(NA_real_, length(cls)))
    )
    return(out)
  }

  node_cluster <- stats::setNames(as.integer(sil_df$carac), as.character(sil_df$name))
  ed <- ed |> dplyr::filter(from %in% names(node_cluster), to %in% names(node_cluster))
  if (!nrow(ed)) {
    out <- tibble::tibble(
      Cluster = c("OVERALL", paste0("C", cls)),
      SS = c(mean(sil_df$sil_width, na.rm = TRUE), vapply(cls, function(cc) mean(sil_df$sil_width[sil_df$carac == cc], na.rm = TRUE), numeric(1))),
      Qw = 0,
      Qu = 0,
      D_GiniSimpson = c(D_overall, rep(NA_real_, length(cls))),
      Q_over_D = c(0, rep(NA_real_, length(cls))),
      OneMinus_1_over_k = c(Dmax_over, rep(NA_real_, length(cls))),
      Q_over_Dmax_eff = c(0, rep(NA_real_, length(cls)))
    )
    return(out)
  }

  m_un <- nrow(ed)
  m_w <- sum(ed$w, na.rm = TRUE)
  if (!is.finite(m_w) || m_w <= 0) m_w <- m_un
  rows <- lapply(cls, function(cc) {
    ids <- names(node_cluster)[node_cluster == cc]
    inside <- ed$from %in% ids & ed$to %in% ids
    deg_un <- sum(ed$from %in% ids) + sum(ed$to %in% ids)
    deg_w <- sum(ed$w[ed$from %in% ids], na.rm = TRUE) + sum(ed$w[ed$to %in% ids], na.rm = TRUE)
    e_un <- sum(inside) / max(1, m_un)
    a_un <- deg_un / max(1, 2 * m_un)
    e_w <- sum(ed$w[inside], na.rm = TRUE) / max(1e-9, m_w)
    a_w <- deg_w / max(1e-9, 2 * m_w)
    tibble::tibble(
      Cluster = paste0("C", cc),
      SS = mean(sil_df$sil_width[sil_df$carac == cc], na.rm = TRUE),
      Qw = e_w - a_w^2,
      Qu = e_un - a_un^2
    )
  })
  by_cl <- dplyr::bind_rows(rows)
  Qw_overall <- sum(by_cl$Qw, na.rm = TRUE)
  Qu_overall <- sum(by_cl$Qu, na.rm = TRUE)
  dplyr::bind_rows(
    tibble::tibble(
      Cluster = "OVERALL",
      SS = mean(sil_df$sil_width, na.rm = TRUE),
      Qw = Qw_overall,
      Qu = Qu_overall,
      D_GiniSimpson = D_overall,
      Q_over_D = if (is.finite(D_overall) && D_overall > 0) Qu_overall / D_overall else NA_real_,
      OneMinus_1_over_k = Dmax_over,
      Q_over_Dmax_eff = if (is.finite(Dmax_over) && Dmax_over > 0) Qu_overall / Dmax_over else NA_real_
    ),
    by_cl |> dplyr::mutate(
      D_GiniSimpson = NA_real_,
      Q_over_D = NA_real_,
      OneMinus_1_over_k = NA_real_,
      Q_over_Dmax_eff = NA_real_
    )
  )
}

.make_ssplot_res_matrix <- function(sil_df, edges = NULL) {
  if (is.null(edges) || !is.data.frame(edges) || !nrow(edges)) return(list(W_km = matrix(0, 0, 0)))
  nm <- as.character(sil_df$name)
  W <- matrix(0, length(nm), length(nm), dimnames = list(nm, nm))
  ed <- tibble::as_tibble(edges)
  from_col <- c("from", "Leader", "leader", "source")[c("from", "Leader", "leader", "source") %in% names(ed)][1]
  to_col   <- c("to", "follower", "Follower", "target")[c("to", "follower", "Follower", "target") %in% names(ed)][1]
  w_col    <- c("weight", "WCD", "width", "value")[c("weight", "WCD", "width", "value") %in% names(ed)][1]
  if (is.na(from_col) || is.na(to_col)) return(list(W_km = W))
  from <- trimws(as.character(ed[[from_col]]))
  to   <- trimws(as.character(ed[[to_col]]))
  w    <- if (!is.na(w_col)) suppressWarnings(as.numeric(ed[[w_col]])) else rep(1, length(from))
  w[!is.finite(w)] <- 1
  for (i in seq_along(from)) {
    a <- from[i]; b <- to[i]
    if (a %in% nm && b %in% nm && a != b) {
      W[a, b] <- W[a, b] + w[i]
      W[b, a] <- W[b, a] + w[i]
    }
  }
  list(W_km = W)
}

.make_ssplot_adapter <- function(nodes, edges = NULL) {
  nd <- tibble::as_tibble(nodes)
  nm <- .make_ssplot_name_vec(nd)
  cl <- .make_ssplot_cluster_vec(nd)
  val <- if ("value" %in% names(nd)) suppressWarnings(as.numeric(nd$value)) else if ("freq" %in% names(nd)) suppressWarnings(as.numeric(nd$freq)) else rep(1, nrow(nd))
  val[!is.finite(val)] <- 1
  val2 <- if ("value2" %in% names(nd)) suppressWarnings(as.numeric(nd$value2)) else val
  val2[!is.finite(val2)] <- val[!is.finite(val2)]
  ss <- if ("ss" %in% names(nd)) suppressWarnings(as.numeric(nd$ss)) else if ("ssi" %in% names(nd)) suppressWarnings(as.numeric(nd$ssi)) else rep(0, nrow(nd))
  ss[!is.finite(ss)] <- 0
  sil_df <- tibble::tibble(name = nm, sil_width = ss, carac = cl, value = val, value2 = val2)

  # cluster leaders + follower single-link labels
  ord <- order(sil_df$carac, -sil_df$value, sil_df$name)
  sil_df <- sil_df[ord, , drop = FALSE]
  leader_by_cluster <- tapply(sil_df$name, sil_df$carac, function(x) x[1])
  sil_df$role <- ifelse(sil_df$name == unname(leader_by_cluster[as.character(sil_df$carac)]), "leader", "follower")
  sil_df$neighbor_name <- unname(leader_by_cluster[as.character(sil_df$carac)])
  sil_df$neighborC <- sil_df$carac
  sil_df$neighborcluster <- sil_df$carac
  sil_df$wsel <- sil_df$value

  nodes0 <- tibble::tibble(name = sil_df$name, carac = sil_df$carac, value = sil_df$value)
  nodes_full <- tibble::tibble(name = sil_df$name, value = sil_df$value, value2 = sil_df$value2, carac = sil_df$carac)
  list(
    sil_df = sil_df,
    nodes0 = nodes0,
    results = .compute_ssplot_results(sil_df, edges),
    res = .make_ssplot_res_matrix(sil_df, edges),
    nodes = nodes_full
  )
}

call_original_plot_ss <- function(nodes, edges = NULL, title = "SSplot") {
  if (!exists("render_panel", mode = "function", inherits = TRUE)) {
    stop("Original render_panel() not found. Please keep renderSSplot.R beside app.R.")
  }
  ad <- .make_ssplot_adapter(nodes, edges)
  render_panel(
    sil_df = ad$sil_df,
    nodes0 = ad$nodes0,
    results = ad$results,
    res = ad$res,
    nodes = ad$nodes,
    top_n = nrow(ad$sil_df),
    aac_col = "#A23B3B",
    aac_side = "left",
    neighbor_side = "right",
    neighbor_on_bar = TRUE,
    footer_label = ""
  )
}

build_reference_payload_from_text <- function(full_text) {
  full_text <- paste(as.character(full_text %||% ""), collapse = "\n")

  ref_sec <- list(found = FALSE, start_index = NULL, reference_text = "", references = character(0), count = 0L, error = "No extractor available")
  ref_rows <- tibble::tibble(ref_no = character(0), reference_raw = character(0), reference_clean = character(0))

  # Prefer Python if available, but fall back to pure R extraction automatically.
  if (exists("py_extract_reference_section_safe", mode = "function")) {
    ref_sec_py <- tryCatch(py_extract_reference_section_safe(full_text), error = function(e) NULL)
    if (!is.null(ref_sec_py) && isTRUE(ref_sec_py$found)) {
      ref_sec <- ref_sec_py
    }
  }
  if (exists("py_extract_reference_coword_rows_safe", mode = "function")) {
    ref_rows_py <- tryCatch(py_extract_reference_coword_rows_safe(full_text), error = function(e) NULL)
    if (!is.null(ref_rows_py) && nrow(ref_rows_py) > 0) {
      ref_rows <- ref_rows_py
    }
  }

  if (!isTRUE(ref_sec$found)) {
    ref_sec <- extract_reference_section_r(full_text)
  }
  if (nrow(ref_rows) == 0) {
    ref_rows <- extract_reference_coword_rows_r(full_text)
  }

  ref_rows <- tibble::as_tibble(ref_rows)
  if (!"ref_no" %in% names(ref_rows)) ref_rows$ref_no <- character(nrow(ref_rows))
  if (!"reference_raw" %in% names(ref_rows)) ref_rows$reference_raw <- character(nrow(ref_rows))
  if (!"reference_clean" %in% names(ref_rows)) ref_rows$reference_clean <- character(nrow(ref_rows))
  ref_rows <- ref_rows[, c("ref_no", "reference_raw", "reference_clean"), drop = FALSE]

  sec_refs <- as.character(unlist(ref_sec$references %||% character(0)))
  if (length(sec_refs) > 0) {
    ref_docs0 <- tibble::tibble(ref_no = seq_along(sec_refs), reference_raw = sec_refs)
  } else if (nrow(ref_rows) > 0) {
    ref_docs0 <- tibble::tibble(ref_no = seq_len(nrow(ref_rows)), reference_raw = as.character(ref_rows$reference_raw))
  } else {
    ref_docs0 <- tibble::tibble(ref_no = integer(0), reference_raw = character(0))
  }
  parsed_entity_rows <- tryCatch(parse_reference_author_journal_rows(ref_docs0), error = function(e) tibble::tibble())
  parsed_docs <- parsed_entity_rows
  if (nrow(parsed_docs) > 0) {
    ref_docs <- parsed_docs |>
      dplyr::group_by(ref_no, reference_raw) |>
      dplyr::summarise(
        authors = paste(unique(entity[entity_type == "author"]), collapse = "; "),
        journal = paste(unique(entity[entity_type == "journal"]), collapse = "; "),
        .groups = "drop"
      ) |>
      dplyr::arrange(suppressWarnings(as.integer(ref_no)))
  } else {
    ref_docs <- ref_docs0
  }

  extractor_msg <- if (isTRUE(py_reference_available())) {
    "Python extractor loaded"
  } else {
    "Python extractor unavailable; used R fallback"
  }

  diag <- tibble::tribble(
    ~check, ~status, ~details,
    "Reference section", if (isTRUE(ref_sec$found)) "OK" else "Info",
    if (isTRUE(ref_sec$found)) {
      paste0("Reference section detected. Extracted ", as.integer(ref_sec$count %||% 0L), " references. ", extractor_msg, ".")
    } else {
      paste0("No explicit references section detected", if (!is.null(ref_sec$error) && nzchar(ref_sec$error)) paste0(" (", ref_sec$error, ")") else ".")
    },
    "Reference rows", if (nrow(parsed_entity_rows) > 0) "OK" else "Warning", paste0("Reference author/journal rows: ", nrow(parsed_entity_rows)),
    "Reference documents", if (nrow(ref_docs) > 0) "OK" else "Warning", paste0("Reference documents: ", nrow(ref_docs))
  )

  ref_net <- build_reference_network_from_rows(ref_docs0, top_n = 20)
  if (is.null(ref_net$diagnostics) || !is.data.frame(ref_net$diagnostics)) ref_net$diagnostics <- tibble::tibble()
  if (nrow(ref_net$diagnostics) > 0) diag <- dplyr::bind_rows(diag, ref_net$diagnostics)
  ama <- check_sequential_ama_r(full_text, ref_docs)

  list(
    documents = ref_docs,
    coword_rows = parsed_entity_rows,
    diagnostics = diag,
    ama = ama,
    network = ref_net
  )
}

DEMO_PDF <- if (file.exists(app_path("data", "SOFTX-S-26-00528.pdf"))) app_path("data", "SOFTX-S-26-00528.pdf") else app_path("SOFTX-S-26-00528.pdf")
DEMO_BBC_URL <- "https://pubmed.ncbi.nlm.nih.gov/40836275/"

empty_dual_result <- function(msg = "Upload a file and press Analyze or Submission readiness report.") {
  empty_net <- list(nodes = data.frame(), edges = data.frame(), graph = NULL, cooc = data.frame(), final_edges = data.frame(), anno_top = data.frame(), aac = data.frame(metric = character(0), AAC = numeric(0)), diagnostics = data.frame())
  list(
    overall = list(documents = data.frame(), diagnostics = data.frame(Message = msg), submission_report = NULL),
    main = list(documents = data.frame(), diagnostics = data.frame(Message = "No main analysis yet."), annotations = data.frame(), rake_keywords = data.frame(), tfidf_summary = data.frame(), tfidf_detail = data.frame(), nodes = data.frame(), edges = data.frame(), anno_top = data.frame(), cooc = data.frame(), final_edges = data.frame(), aac = data.frame(metric = character(0), AAC = numeric(0)), mesh = mesh_empty_result()),
    references = empty_reference_payload()
  )
}

csv_button_row <- function(prefix) {
  tagList(
    fluidRow(
      column(4, downloadButton(paste0(prefix, "_anno_dl"), "Download anno_top.csv")),
      column(4, downloadButton(paste0(prefix, "_cooc_dl"), "Download cooc.csv")),
      column(4, downloadButton(paste0(prefix, "_edges_dl"), "Download final_edges.csv"))
    )
  )
}

plot_bundle_ui <- function(prefix, include_coword = FALSE) {
  tabs <- list(
    tabPanel("Network", br(), visNetwork::visNetworkOutput(paste0(prefix, "_net_plot"), height = "700px")),
    tabPanel("SSplot", br(), plotOutput(paste0(prefix, "_ss_plot"), height = "620px")),
    tabPanel("Kano",
      br(), uiOutput(paste0(prefix, "_kano_aac_ui")), br(),
      plotOutput(paste0(prefix, "_kano_plot"), height = "520px"), br(),
      plotOutput(paste0(prefix, "_ssastar_plot"), height = "520px"), br(),
      plotly::plotlyOutput(paste0(prefix, "_sskano_plotly"), height = "480px")
    ),
    tabPanel("Sankey", br(), uiOutput(paste0(prefix, "_sankey_ui"))),
    tabPanel("Nodes", br(), DT::DTOutput(paste0(prefix, "_nodes_tbl"))),
    tabPanel("Relations", br(), DT::DTOutput(paste0(prefix, "_edges_tbl")))
  )
  if (isTRUE(include_coword)) {
    tabs <- c(tabs, list(
      tabPanel("Coword used data",
        br(), htmlOutput(paste0(prefix, "_coword_summary")), br(),
        csv_button_row(prefix), br(),
        h4("anno_top (term rows sent to network)"), DT::DTOutput(paste0(prefix, "_anno_top_tbl")), br(),
        h4("cooc (coword occurrences before FLCA)"), DT::DTOutput(paste0(prefix, "_cooc_tbl")), br(),
        h4("final_edges (FLCA relations used in network)"), DT::DTOutput(paste0(prefix, "_final_edges_tbl"))
      )
    ))
  }
  do.call(tabsetPanel, tabs)
}

ui <- fluidPage(
  tags$head(tags$style(HTML("
  #file_box .btn, #file_box .form-control {background-color:#eaffea !important; border-color:#58b957 !important;}
  #file_box label.control-label {color:#1f7a1f; font-weight:700;}
  "))),
  titlePanel("Submission Review Upload -> Main / References -> FLCA Network, SSplot, Kano, Sankey, AAC Dashboard"),
  sidebarLayout(
    sidebarPanel(
      actionButton("use_demo_pdf", "Use bundled demo PDF", class = "btn-info"),
      tags$div(style = "margin-top:6px;margin-bottom:8px;color:#555;", sprintf("Bundled demo: %s", DEMO_PDF)),
      checkboxInput("use_url", "Extract keywords from website instead of uploaded file", value = FALSE),
      conditionalPanel(
        condition = "input.use_url",
        textInput("source_url", "Website link", value = "https://pubmed.ncbi.nlm.nih.gov/40836275/"),
        tags$div(style = "margin-top:-6px;margin-bottom:10px;", tags$a(href = "https://pubmed.ncbi.nlm.nih.gov/40836275/", target = "_blank", "Open default example: PubMed 40836275"))
      ),
      conditionalPanel(
        condition = "!input.use_url",
        div(id = "file_box", fileInput("file_upload", "Upload PDF, DOCX, TXT, or CSV", accept = c(".pdf", ".docx", ".txt", ".csv"))),
        uiOutput("csv_col_ui")
      ),
      selectInput(
        "ud_lang",
        "Language / UDPipe model",
        choices = c(
          "English" = "english",
          "Chinese (Simplified)" = "chinese",
          "Chinese (Traditional)" = "chinese",
          "Spanish" = "spanish",
          "French" = "french",
          "German" = "german",
          "Italian" = "italian",
          "Portuguese" = "portuguese",
          "Dutch" = "dutch",
          "Japanese" = "japanese",
          "Korean" = "korean",
          "Russian" = "russian",
          "Arabic" = "arabic",
          "Turkish" = "turkish"
        ),
        selected = "english"
      ),
      checkboxGroupInput("pos_keep", "Keep parts of speech for main-document UDPipe mode", choices = c("NOUN", "PROPN", "ADJ", "VERB"), selected = c("NOUN", "PROPN", "ADJ")),
      numericInput("top_n", "Candidate pool before final top-20", value = 80, min = 20, max = 300, step = 10),
      numericInput("min_freq", "Minimum term/entity frequency", value = 2, min = 1, max = 100, step = 1),
      numericInput("min_cooc", "Minimum co-occurrence", value = 2, min = 1, max = 100, step = 1),
      fluidRow(
        column(6, actionButton("run_btn", "Analyze", class = "btn-primary")),
        column(6, actionButton("run_submission_btn", "Run submission report", class = "btn-default"))
      ),
      hr(),
      helpText("Revision notes:"),
      tags$ul(
        tags$li("Main and References both include Coword used data with anno_top, cooc, and final_edges downloads."),
        tags$li("Nodes are colored by FLCA cluster in the network."),
        tags$li("References only use AMA-style authors + journal extracted from numbered reference lines. Non-AMA or HTML-style reference sections are best-effort only."),
        tags$li("Leader-first trace: original document keywords stay fixed as cluster leaders; main-document members are limited to 1-3 words and must come from Abstract / Software description / Impact-Conclusion sections."),
        tags$li("Kano tabs include standard Kano plus interactive SS-Kano. AAC is now a dashboard/computation tab.")
      )
    ),
    mainPanel(
      tabsetPanel(id = "main_tabs",
        tabPanel("Overview", br(), h4("Overall diagnostics"), DT::DTOutput("diag_tbl"), br(), h4("Uploaded documents"), DT::DTOutput("docs_tbl")),
        tabPanel("ReadME", br(), uiOutput("readme_ui")),
        tabPanel("Submission Readiness Report", br(), uiOutput("submission_report_ui")),
        tabPanel("Keyword Leader-Member Trace",
          br(),
          tags$p(style = "color:#555;", "Leaders are fixed to the document's original Keywords section. Members are extracted only from Abstract / Software description / Impact-Conclusion sections, limited to 1-3 words, and then aligned to the nearest leader."),
          h4("1. Original keywords (leaders)"), DT::DTOutput("tbl_trace_leaders"),
          br(),
          h4("2. Additional keywords aligned with MeSH terms (members)"), DT::DTOutput("tbl_trace_members"),
          br(),
          h4("3. Final top 20 keywords after FLCA-SIL-MA"), DT::DTOutput("tbl_trace_final")
        ),
        tabPanel("Keywords", br(), h4("RAKE keywords (main document)"), DT::DTOutput("rake_tbl"), br(), h4("TF-IDF summary (main document)"), DT::DTOutput("tfidf_summary_tbl"), br(), h4("TF-IDF detail (main document)"), DT::DTOutput("tfidf_detail_tbl")),
        tabPanel("MeSH Keywords", br(), h4("MeSH validation summary"), DT::DTOutput("mesh_summary_tbl"), br(), h4("Candidate terms validated against PubMed / MeSH"), DT::DTOutput("mesh_candidates_tbl"), br(), h4("Reference-backed MeSH terms"), DT::DTOutput("mesh_reference_tbl")),
        tabPanel("Main Document", plot_bundle_ui("main", include_coword = TRUE)),
        tabPanel("References",
          tabsetPanel(
            tabPanel("Reference Extract",
              br(),
              h4("Extracted references: serial no., authors, journal"),
              DT::DTOutput("ref_docs_tbl"),
              br(),
              h4("Reference coword term rows"),
              DT::DTOutput("ref_coword_map_tbl"),
              br(),
              DT::DTOutput("ref_diag_tbl")
            ),
            tabPanel("Sequential AMA",
              br(),
              htmltools::div(
                style = "padding:10px 14px;border:1px solid #d7e3f4;border-radius:10px;background:#f7fbff;color:#173f6b;",
                htmltools::strong("This tab checks numbered AMA-style in-text citations against the extracted reference list."),
                htmltools::tags$ul(
                  htmltools::tags$li("It checks whether first appearance is sequential (1, 2, 3, ...)."),
                  htmltools::tags$li("It checks whether cited numbers exist in the reference list."),
                  htmltools::tags$li("It also shows reference entries that were never cited in the body text.")
                )
              ),
              br(),
              h4("Sequential AMA diagnostics"),
              DT::DTOutput("ama_diag_tbl"),
              br(),
              h4("First appearance order of cited numbers"),
              DT::DTOutput("ama_seq_tbl"),
              br(),
              h4("Reference list numbering and whether cited"),
              DT::DTOutput("ama_ref_tbl"),
              br(),
              h4("Citation groups found in body text"),
              DT::DTOutput("ama_hits_tbl")
            ),
            tabPanel("Nodes", br(), DT::DTOutput("ref_nodes_tbl")),
            tabPanel("Relations",
              br(),
              htmltools::div(
                style = "padding:10px 14px;border:1px solid #d7e3f4;border-radius:10px;background:#f7fbff;color:#173f6b;",
                htmltools::strong("Two relation layers are shown here:"),
                htmltools::tags$ul(
                  htmltools::tags$li("raw co-word edges = all aggregated journal/author co-occurrences before FLCA"),
                  htmltools::tags$li("FLCA final relations = sampled/filtered directed relations used in the final network")
                )
              ),
              br(),
              h4("Raw co-word edges"),
              DT::DTOutput("ref_raw_edges_tbl"),
              br(),
              h4("FLCA final relations"),
              DT::DTOutput("ref_edges_tbl")
            ),
            tabPanel("Coword used data",
              br(), htmlOutput("ref_coword_summary"), br(),
              csv_button_row("ref"), br(),
              h4("anno_top (term rows sent to network)"), DT::DTOutput("ref_anno_top_tbl"), br(),
              h4("cooc (coword occurrences before FLCA)"), DT::DTOutput("ref_cooc_tbl"), br(),
              h4("final_edges (FLCA relations used in network)"), DT::DTOutput("ref_final_edges_tbl")
            ),
            tabPanel("Network", br(), visNetwork::visNetworkOutput("ref_net_plot", height = "700px")),
            tabPanel("SSplot", br(), plotOutput("ref_ss_plot", height = "620px")),
            tabPanel("Kano",
              br(), uiOutput("ref_kano_aac_ui"), br(),
              plotOutput("ref_kano_plot", height = "520px"), br(),
              plotly::plotlyOutput("ref_sskano_plotly", height = "480px")
            ),
            tabPanel("Sankey", br(), uiOutput("ref_sankey_ui"))
          )
        ),
        tabPanel("AAC Dashboard",
          tabsetPanel(
            tabPanel("AAC calculator",
              br(),
              fluidRow(
                column(4,
                  div(style = "font-size:34px;font-weight:800;text-align:center;padding:12px 0;border:1px solid #ddd;border-radius:14px;margin-bottom:12px;", textOutput("aac_calc_txt")),
                  div(style = "text-align:center;color:#666;margin-top:-6px;margin-bottom:10px;", textOutput("abc_calc_txt")),
                  sliderInput("B", "Adjust B. Constraints: A = 2.99 - B, and C ≤ B ≤ A", min = 0.01, max = (3 - 0.01)/2, value = 0.8, step = 0.001)
                ),
                column(8, plotOutput("aac_calc_plot", height = 380))
              )
            ),
            tabPanel("Main AAC", br(), uiOutput("main_aac_dash_ui"), br(), DT::DTOutput("main_aac_tbl")),
            tabPanel("Reference AAC", br(), uiOutput("ref_aac_dash_ui"), br(), DT::DTOutput("ref_aac_tbl"))
          )
        ),
        tabPanel("Downloads",
          br(),
          h4("PNG downloads"),
          p("Use this tab to export the current plots as PNG files. If a plot has no data yet, the corresponding file will be empty or trigger a validation message."),
          fluidRow(
            column(6, tags$h5("Main document"),
              downloadButton("dl_main_network_png", "main_network.png"), br(), br(),
              downloadButton("dl_main_ss_png", "main_ssplot.png"), br(), br(),
              downloadButton("dl_main_kano_png", "main_kano.png"), br(), br(),
              downloadButton("dl_main_sskano_png", "main_sskano.png")
            ),
            column(6, tags$h5("References"),
              downloadButton("dl_ref_network_png", "ref_network.png"), br(), br(),
              downloadButton("dl_ref_ss_png", "ref_ssplot.png"), br(), br(),
              downloadButton("dl_ref_kano_png", "ref_kano.png"), br(), br(),
              downloadButton("dl_ref_sskano_png", "ref_sskano.png")
            )
          )
        )
      )
    )
  )

)

server <- function(input, output, session) {
  observe({
    qs <- tryCatch(shiny::parseQueryString(session$clientData$url_search %||% ""), error = function(e) list())
    u <- qs[["url"]] %||% qs[["source_url"]] %||% ""
    if (nzchar(u)) {
      updateCheckboxInput(session, "use_url", value = TRUE)
      updateTextInput(session, "source_url", value = u)
    }
  })
  upload_info <- reactiveVal(NULL)
  analysis_res <- reactiveVal(empty_dual_result())

  observeEvent(input$use_demo_pdf, {
    if (!file.exists(DEMO_PDF)) {
      showNotification(sprintf("Demo PDF not found at %s", DEMO_PDF), type = "error")
    } else {
      updateCheckboxInput(session, "use_url", value = FALSE)
      upload_info(list(path = DEMO_PDF, name = basename(DEMO_PDF), ext = "pdf", csv_cols = NULL, source = "demo"))
      showNotification(sprintf("Demo PDF selected: %s", DEMO_PDF), type = "message")
      analysis_res(empty_dual_result(sprintf("Demo PDF selected: %s. Press Analyze to run.", DEMO_PDF)))
    }
  })

  observeEvent(input$file_upload, {
    req(input$file_upload)
    ext <- tolower(tools::file_ext(input$file_upload$name))
    csv_cols <- NULL
    if (ext == "csv") {
      dat <- tryCatch(readr::read_csv(input$file_upload$datapath, show_col_types = FALSE, progress = FALSE), error = function(e) NULL)
      if (!is.null(dat)) csv_cols <- names(dat)
    }
    upload_info(list(path = input$file_upload$datapath, name = input$file_upload$name, ext = ext, csv_cols = csv_cols, source = "file"))
    analysis_res(empty_dual_result())
  })

  output$csv_col_ui <- renderUI({
    info <- upload_info()
    if (is.null(info) || info$ext != "csv") return(NULL)
    selectInput("csv_text_col", "CSV text column", choices = info$csv_cols, selected = info$csv_cols[1] %||% character(0))
  })

  observeEvent(input$run_submission_btn, {
    updateTabsetPanel(session, "main_tabs", selected = "Submission Readiness Report")
    withProgress(message = "Preparing submission readiness report", value = 0, {
      tryCatch({
        if (isTRUE(input$use_url)) {
          incProgress(0.2, detail = "Reading website text")
          docs <- read_website_documents(input$source_url, language = input$ud_lang)
          src_ext <- "html"
          checked_name <- input$source_url %||% "Website"
        } else {
          info <- upload_info(); req(info)
          incProgress(0.2, detail = "Reading selected file")
          docs <- read_uploaded_documents(path = info$path, ext = info$ext, csv_text_col = if (identical(info$ext, "csv")) input$csv_text_col else NULL)
          src_ext <- info$ext
          checked_name <- info$name %||% "Uploaded file"
        }
        incProgress(0.55, detail = "Extracting sections and references")
        ref_payload <- build_reference_payload_from_docs(docs, src_ext)
        rep <- submission_readiness_from_docs(docs, src_ext, checked_name = checked_name, ref_payload = ref_payload)
        res <- empty_dual_result()
        res$overall$documents <- tibble::tibble(name = checked_name, ext = src_ext, rows = nrow(docs), characters = nchar(docs_to_full_text(docs)))
        res$overall$diagnostics <- rep$diagnostics
        res$overall$submission_report <- rep
        res$references <- ref_payload
        if (exists("apply_leader_member_trace_patch36", mode = "function")) {
          res <- apply_leader_member_trace_patch36(res = res, docs = docs, mesh_res = NULL, top_n = as.integer(input$top_n), final_n = 20)
        }
        analysis_res(res)
        incProgress(0.95, detail = "Rendering report")
        showNotification("Submission readiness report updated from the uploaded manuscript.", type = "message")
      }, error = function(e) {
        analysis_res(empty_dual_result(as.character(e$message)))
        showNotification(paste("Submission readiness failed:", e$message), type = "error", duration = NULL)
      })
    })
  })

  observeEvent(input$run_btn, {
    withProgress(message = "Analyzing text", value = 0, {
      tryCatch({
        if (isTRUE(input$use_url)) {
          incProgress(0.1, detail = "Reading website text")
          docs <- read_website_documents(input$source_url, language = input$ud_lang)
          src_ext <- "html"
        } else {
          info <- upload_info(); req(info)
          incProgress(0.1, detail = "Reading selected file")
          docs <- read_uploaded_documents(path = info$path, ext = info$ext, csv_text_col = if (identical(info$ext, "csv")) input$csv_text_col else NULL)
          src_ext <- info$ext
        }
        incProgress(0.35, detail = "Running main and reference analyses")
        res <- run_dual_aspect_analysis(docs = docs, ext = src_ext, language = input$ud_lang, pos_keep = input$pos_keep, top_n = as.integer(input$top_n), min_freq = as.integer(input$min_freq), min_cooc = as.integer(input$min_cooc))
        full_text <- docs_to_full_text(docs)
        ref_payload <- build_reference_payload_from_docs(docs, src_ext)
        mesh_res <- tryCatch({
          if (exists("mesh_validate_terms", mode = "function")) {
            # PubMed/MeSH validation entry point
            mesh_validate_terms(
              full_text = full_text,
              ref_docs = ref_payload$documents,
              max_candidate_terms = 40,
              max_pmids_per_term = 5,
              max_references = 20
            )
          } else {
            mesh_empty_result("mesh_keyword_validation.R not loaded.")
          }
        }, error = function(e) {
          mesh_empty_result(as.character(e$message))
        })
        if (is.null(mesh_res) || !is.list(mesh_res)) mesh_res <- mesh_empty_result("Invalid mesh result")
        if (is.null(mesh_res$candidates) || !is.data.frame(mesh_res$candidates)) mesh_res$candidates <- tibble::tibble(term = character(0), source = character(0), tier = character(0), pubmed_hit_count = integer(0), mesh_exact = logical(0), mesh_partial = logical(0), reference_mesh_support = logical(0), mesh_terms_found = character(0), pmid_examples = character(0), mesh_supported = logical(0), confidence = character(0))
        if (!"mesh_term" %in% names(mesh_res$candidates)) mesh_res$candidates$mesh_term <- character(nrow(mesh_res$candidates))
        if (is.null(mesh_res$reference_mesh) || !is.data.frame(mesh_res$reference_mesh)) mesh_res$reference_mesh <- tibble::tibble(ref_no = integer(0), pmid = character(0), mesh_term = character(0), mesh_major = character(0), matched_by = character(0))
        if (!"mesh_term" %in% names(mesh_res$reference_mesh)) mesh_res$reference_mesh$mesh_term <- character(nrow(mesh_res$reference_mesh))
        if (is.null(res$references) || !is.list(res$references)) res$references <- empty_reference_payload()
        if (nrow(ref_payload$documents) > 0) res$references$documents <- ref_payload$documents
        if (nrow(ref_payload$coword_rows) > 0) res$references$coword_rows <- ref_payload$coword_rows else if (is.null(res$references$coword_rows)) res$references$coword_rows <- ref_payload$coword_rows
        res$references$diagnostics <- ref_payload$diagnostics
        res$references$ama <- ref_payload$ama
        res$references$network <- ref_payload$network %||% empty_reference_network()
        if (exists("apply_leader_member_trace_patch36", mode = "function")) {
          res <- tryCatch({
            apply_leader_member_trace_patch36(res = res, docs = docs, mesh_res = mesh_res, top_n = as.integer(input$top_n), final_n = 20)
          }, error = function(e) {
            append_overall_diagnostic(res, "Keyword leader-member trace", "Warning", paste0("Trace patch skipped: ", as.character(e$message)))
          })
        } else if (exists("apply_keyword_priority_to_result_patch2", mode = "function")) {
          res <- tryCatch({
            apply_keyword_priority_to_result_patch2(res = res, docs = docs, top_n = as.integer(input$top_n), mesh_res = mesh_res, final_n = 20)
          }, error = function(e) {
            append_overall_diagnostic(res, "Keyword priority patch", "Warning", paste0("Keyword priority patch skipped: ", as.character(e$message)))
          })
        } else if (exists("apply_keyword_priority_to_result_patch", mode = "function")) {
          res <- tryCatch({
            apply_keyword_priority_to_result_patch(res = res, docs = docs, top_n = as.integer(input$top_n), final_n = 20)
          }, error = function(e) {
            append_overall_diagnostic(res, "Keyword priority patch", "Warning", paste0("Keyword priority patch skipped: ", as.character(e$message)))
          })
        }
        if (exists("repair_reference_terms_and_network2", mode = "function")) {
          res$references <- tryCatch({
            repair_reference_terms_and_network2(ref_payload = res$references, top_n = 20)
          }, error = function(e) {
            res <<- append_overall_diagnostic(res, "Reference network repair", "Warning", paste0("Reference repair skipped: ", as.character(e$message)))
            res$references
          })
        } else if (exists("repair_reference_terms_and_network", mode = "function")) {
          res$references <- tryCatch({
            repair_reference_terms_and_network(ref_payload = res$references, top_n = 20, entity_mode = "authors_journal")
          }, error = function(e) {
            res <<- append_overall_diagnostic(res, "Reference network repair", "Warning", paste0("Reference repair skipped: ", as.character(e$message)))
            res$references
          })
        } else if (exists("repair_reference_network_patch", mode = "function")) {
          res$references <- tryCatch({
            repair_reference_network_patch(ref_payload = res$references, top_n = 20)
          }, error = function(e) {
            res <<- append_overall_diagnostic(res, "Reference network repair", "Warning", paste0("Reference repair skipped: ", as.character(e$message)))
            res$references
          })
        }
        if (is.null(res$main) || !is.list(res$main)) res$main <- list()
        res$main$mesh <- mesh_res
        checked_name <- if (!isTRUE(input$use_url)) (upload_info()$name %||% "Uploaded file") else (input$source_url %||% "Website")
        res$overall$submission_report <- submission_readiness_from_docs(docs, src_ext, checked_name = checked_name, ref_payload = ref_payload)
        incProgress(0.8, detail = "Rendering outputs")
        analysis_res(res)
        showNotification("Analysis completed. Main and reference tabs were updated.", type = "message")
      }, error = function(e) {
        analysis_res(empty_dual_result(as.character(e$message)))
        showNotification(paste("Analysis failed:", e$message), type = "error", duration = NULL)
      })
    })
  })

  render_dt <- function(expr, page = 20, dom = NULL) {
    DT::renderDT({
      df <- expr()
      DT::datatable(df, options = c(list(pageLength = page, scrollX = TRUE), if (!is.null(dom)) list(dom = dom) else list()))
    })
  }

  output$diag_tbl <- render_dt(function() analysis_res()$overall$diagnostics, page = 10)
  output$docs_tbl <- render_dt(function() analysis_res()$overall$documents, page = 8)
  output$submission_report_ui <- renderUI({
    rep <- analysis_res()$overall$submission_report
    if (is.null(rep) || !is.list(rep)) rep <- submission_readiness_from_result(analysis_res())
    render_submission_report_ui(rep)
  })

  output$readme_ui <- renderUI({
    htmltools::tagList(
      tags$div(style = "padding:12px 16px;border:1px solid #d7e3f4;border-radius:10px;background:#f7fbff;",
        tags$h4("Reference article and demo sources"),
        tags$ul(
          tags$li(
            tags$a(
              href = "https://www.sciencedirect.com/science/article/pii/S2352711026000841",
              target = "_blank",
              "TALL: Text analysis for all–an interactive R-shiny application for exploring, modeling, and visualizing textual data"
            )
          ),
          tags$li("The BBC News and Twitter US airline datasets are cited in the TALL article bibliography/examples.")
        ),
        tags$h4("Input data forms"),
        tags$ul(
          tags$li("Upload PDF, DOCX, TXT, or CSV files. For CSV, select the text column after upload."),
          tags$li("Important: this app is designed primarily for AMA-style numbered references. Bracket-style references such as [1]...[n] and website reference sections are handled heuristically and may need manual checking."),
          tags$li(sprintf("Bundled demo PDF is available at %s and can be selected with the button in the sidebar.", DEMO_PDF)),
          tags$li("You can also check the website option and supply a URL. The default example is PubMed 40836275."),
          tags$li("PDF works best when it is a digital text PDF. Scanned image PDFs may need OCR first.")
        ),
        tags$h4("Language limits"),
        tags$ul(
          tags$li("This app provides a convenience dropdown for frequent UDPipe model labels: English, Chinese, Spanish, French, German, Italian, Portuguese, Dutch, Japanese, Korean, Russian, Arabic, and Turkish."),
          tags$li("Chinese (Simplified) and Chinese (Traditional) currently map to the same UDPipe label in this app."),
          tags$li("Actual availability depends on whether the corresponding UDPipe model can be downloaded in your environment.")
        ),
        tags$h4("Analysis workflow"),
        tags$ul(
          tags$li("Main document: annotations -> candidate terms -> coword occurrences -> FLCA top-20 network -> SSplot / Kano / Sankey."),
          tags$li("References: only AMA-style authors and journal names are kept from each reference line before building the reference network. Use Reference Extract and Coword used data to verify the extraction before trusting the plots."),
          tags$li("The References tab now mirrors Main Document with Network, SSplot, Kano, Sankey, Nodes, Relations, and Coword used data tabs. The Relations tab shows both raw co-word edges and FLCA final relations."),
          tags$li("Coword used data tabs show anno_top, cooc, and final_edges for both main and reference analyses. The Downloads tab exports PNG plots and CSV data downloads are available inside each Coword used data tab.")
        )
      )
    )
  })

  output$rake_tbl <- render_dt(function() analysis_res()$main$rake_keywords)
  output$tfidf_summary_tbl <- render_dt(function() analysis_res()$main$tfidf_summary)
  output$tfidf_detail_tbl <- render_dt(function() analysis_res()$main$tfidf_detail)
  output$mesh_summary_tbl <- render_dt(function() analysis_res()$main$mesh$summary, page = 10, dom = "t")
  output$mesh_candidates_tbl <- render_dt(function() analysis_res()$main$mesh$candidates, page = 20)
  output$mesh_reference_tbl <- render_dt(function() analysis_res()$main$mesh$reference_mesh, page = 20)

  bundle_prefixes <- c("main", "ref")
  bundle_exprs <- list(
    main = function() analysis_res()$main,
    ref = function() analysis_res()$references$network
  )

  for (prefix in bundle_prefixes) {
    local({
      pfx <- prefix
      expr_fun <- bundle_exprs[[pfx]]
      output[[paste0(pfx, "_nodes_tbl")]] <- render_dt(function() expr_fun()$nodes)
      if (identical(pfx, "ref")) {
        output[[paste0(pfx, "_raw_edges_tbl")]] <- render_dt(function() expr_fun()$cooc)
      }
      output[[paste0(pfx, "_edges_tbl")]] <- render_dt(function() expr_fun()$edges)
      output[[paste0(pfx, "_anno_top_tbl")]] <- render_dt(function() expr_fun()$anno_top)
      output[[paste0(pfx, "_cooc_tbl")]] <- render_dt(function() expr_fun()$cooc)
      output[[paste0(pfx, "_final_edges_tbl")]] <- render_dt(function() expr_fun()$final_edges)
      output[[paste0(pfx, "_coword_summary")]] <- renderUI({
        res <- expr_fun()
        htmltools::div(
          style = "padding:10px 14px;border:1px solid #d7e3f4;border-radius:10px;background:#f7fbff;color:#173f6b;",
          sprintf("anno_top rows: %s | cooc rows: %s | final_edges rows: %s", nrow(res$anno_top %||% data.frame()), nrow(res$cooc %||% data.frame()), nrow(res$final_edges %||% data.frame()))
        )
      })
      output[[paste0(pfx, "_net_plot")]] <- visNetwork::renderVisNetwork({ vis_network_clustered(expr_fun()$nodes, expr_fun()$edges) })
      output[[paste0(pfx, "_ss_plot")]] <- renderPlot({
        nd <- expr_fun()$nodes
        validate(need(is.data.frame(nd) && nrow(nd) > 0, sprintf("No %s SSplot available.", pfx)))
        call_original_plot_ss(nd, edges = expr_fun()$edges, title = paste(gsub("_", " ", pfx), "SSplot"))
      })
      output[[paste0(pfx, "_kano_plot")]] <- renderPlot({
        nd <- expr_fun()$nodes
        validate(need(is.data.frame(nd) && nrow(nd) > 0, sprintf("No %s Kano plot available.", pfx)))
        plot_kano(nd, title = paste(gsub("_", " ", pfx), "Kano plot"))
      })
      output[[paste0(pfx, "_ssastar_plot")]] <- renderPlot({
        nd <- expr_fun()$nodes
        validate(need(is.data.frame(nd) && nrow(nd) > 0, sprintf("No %s SS/a* Kano plot available.", pfx)))
        plot_ss_astar_kano(nd, title = paste(gsub("_", " ", pfx), "SS vs a* Kano"))
      })
      output[[paste0(pfx, "_sskano_plotly")]] <- plotly::renderPlotly({
        nd <- expr_fun()$nodes
        validate(need(is.data.frame(nd) && nrow(nd) > 0, sprintf("No %s SS-Kano data available.", pfx)))
        plot_ss_kano_interactive(nd, title = paste(gsub("_", " ", pfx), "SS-Kano"))
      })
      output[[paste0(pfx, "_kano_aac_ui")]] <- renderUI({ render_aac_box(expr_fun()$aac, title = paste(gsub("_", " ", pfx), "AAC summary")) })
      output[[paste0(pfx, "_sankey_ui")]] <- renderUI({ render_sankey_widget(expr_fun()$nodes, expr_fun()$edges) })
      output[[paste0(pfx, "_anno_dl")]] <- downloadHandler(
        filename = function() paste0(pfx, "_anno_top.csv"),
        content = function(file) utils::write.csv(as.data.frame(expr_fun()$anno_top, stringsAsFactors = FALSE), file, row.names = FALSE, fileEncoding = "UTF-8")
      )
      output[[paste0(pfx, "_cooc_dl")]] <- downloadHandler(
        filename = function() paste0(pfx, "_cooc.csv"),
        content = function(file) utils::write.csv(as.data.frame(expr_fun()$cooc, stringsAsFactors = FALSE), file, row.names = FALSE, fileEncoding = "UTF-8")
      )
      output[[paste0(pfx, "_edges_dl")]] <- downloadHandler(
        filename = function() paste0(pfx, "_final_edges.csv"),
        content = function(file) utils::write.csv(as.data.frame(expr_fun()$final_edges, stringsAsFactors = FALSE), file, row.names = FALSE, fileEncoding = "UTF-8")
      )
    })
  }

  output$ref_docs_tbl <- render_dt(function() analysis_res()$references$documents, page = 15)
  output$ref_coword_map_tbl <- render_dt(function() analysis_res()$references$coword_rows, page = 20)
  output$ref_diag_tbl <- render_dt(function() analysis_res()$references$diagnostics, dom = 't')
  output$ama_diag_tbl <- render_dt(function() analysis_res()$references$ama$diagnostics, page = 20, dom = 't')
  output$ama_seq_tbl <- render_dt(function() analysis_res()$references$ama$sequence, page = 20)
  output$ama_ref_tbl <- render_dt(function() analysis_res()$references$ama$reference_list, page = 20)
  output$ama_hits_tbl <- render_dt(function() analysis_res()$references$ama$hits, page = 20)

  # AAC calculator based on app(4).zip concept
  vals_calc <- reactive({
    B <- input$B %||% 0.8
    C <- 0.01
    B <- max(B, C)
    A <- (3 - 0.01) - B
    r <- (A * C) / (B^2)
    aac <- r / (1 + r)
    list(A = A, B = B, C = C, r = r, AAC = aac)
  })
  output$aac_calc_txt <- renderText({ sprintf("AAC = %.2f", vals_calc()$AAC) })
  output$abc_calc_txt <- renderText({ v <- vals_calc(); sprintf("A = %.3f, B = %.3f, C = %.2f", v$A, v$B, v$C) })
  output$aac_calc_plot <- renderPlot({
    v <- vals_calc()
    df <- data.frame(var = factor(c("A", "B", "C"), levels = c("A", "B", "C")), val = c(v$A, v$B, v$C))
    ggplot2::ggplot(df, ggplot2::aes(x = var, y = val, group = 1)) +
      ggplot2::geom_line(linewidth = 1) +
      ggplot2::geom_point(size = 4) +
      ggplot2::scale_y_continuous(limits = c(0, 3), breaks = seq(0, 3, 0.5)) +
      ggplot2::labs(x = NULL, y = "Value", title = "AAC computation dashboard") +
      ggplot2::theme_minimal(base_size = 14)
  })

  output$main_aac_dash_ui <- renderUI({ render_aac_dashboard(analysis_res()$main$aac, title = "Main AAC dashboard") })
  output$ref_aac_dash_ui <- renderUI({ render_aac_dashboard(analysis_res()$references$network$aac, title = "Reference AAC dashboard") })
  output$main_aac_tbl <- render_dt(function() analysis_res()$main$aac, dom = 't')
  output$ref_aac_tbl <- render_dt(function() analysis_res()$references$network$aac, dom = 't')

  png_dl <- function(filename_default, plot_fun, width = 1400, height = 1000, res = 120) {
    downloadHandler(
      filename = function() filename_default,
      content = function(file) {
        grDevices::png(file, width = width, height = height, res = res)
        on.exit(grDevices::dev.off(), add = TRUE)
        plot_fun()
      }
    )
  }

  output$dl_main_network_png <- png_dl("main_network.png", function() plot_network_static(analysis_res()$main$nodes, analysis_res()$main$edges, title = "Main document network"))
  output$dl_main_ss_png <- png_dl("main_ssplot.png", function() call_original_plot_ss(analysis_res()$main$nodes, edges = analysis_res()$main$edges, title = "Main document SSplot"))
  output$dl_main_kano_png <- png_dl("main_kano.png", function() plot_kano(analysis_res()$main$nodes, title = "Main document Kano plot"))
  output$dl_main_sskano_png <- png_dl("main_sskano.png", function() print(plot_ss_kano_interactive(analysis_res()$main$nodes, title = "Main document SS-Kano")))

  output$dl_ref_network_png <- png_dl("ref_network.png", function() plot_network_static(analysis_res()$references$network$nodes, analysis_res()$references$network$edges, title = "Reference network"))
  output$dl_ref_ss_png <- png_dl("ref_ssplot.png", function() call_original_plot_ss(analysis_res()$references$network$nodes, edges = analysis_res()$references$network$edges, title = "Reference SSplot"))
  output$dl_ref_kano_png <- png_dl("ref_kano.png", function() plot_kano(analysis_res()$references$network$nodes, title = "Reference Kano plot"))
  output$dl_ref_sskano_png <- png_dl("ref_sskano.png", function() print(plot_ss_kano_interactive(analysis_res()$references$network$nodes, title = "Reference SS-Kano")))

  output$tbl_trace_leaders <- DT::renderDT({
    tr <- analysis_res()$keyword_trace %||% analysis_res()$main$leader_member_trace %||% NULL
    validate(shiny::need(!is.null(tr) && is.data.frame(tr$leaders), "No keyword leader trace available."))
    DT::datatable(tr$leaders, rownames = FALSE, options = list(pageLength = 10, scrollX = TRUE))
  })

  output$tbl_trace_members <- DT::renderDT({
    tr <- analysis_res()$keyword_trace %||% analysis_res()$main$leader_member_trace %||% NULL
    validate(shiny::need(!is.null(tr) && is.data.frame(tr$additional_members), "No keyword member trace available."))
    DT::datatable(tr$additional_members, rownames = FALSE, options = list(pageLength = 10, scrollX = TRUE))
  })

  output$tbl_trace_final <- DT::renderDT({
    tr <- analysis_res()$keyword_trace %||% analysis_res()$main$leader_member_trace %||% NULL
    validate(shiny::need(!is.null(tr) && is.data.frame(tr$final_top20_after_flca), "No final keyword trace available."))
    DT::datatable(tr$final_top20_after_flca, rownames = FALSE, options = list(pageLength = 10, scrollX = TRUE))
  })

}


# Reload keyword/reference patch after app-local defaults so the overrides really take effect.
.patch_reload <- app_path(file.path("R", "zzz_final_integrated_fix.R"))
if (file.exists(.patch_reload)) {
  source(.patch_reload, local = TRUE, encoding = "UTF-8")
  message("[patch] Re-loaded R/zzz_final_integrated_fix.R after app defaults")
}

shinyApp(ui, server)
